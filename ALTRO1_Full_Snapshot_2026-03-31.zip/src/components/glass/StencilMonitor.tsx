/* (c) 2026 SERGEI NAZARIAN | MIT License | ALTRO Glass Engine */
'use client';

import { useState, useMemo } from 'react';
import { CommandBar } from './CommandBar';
import { GlassLanguageSelect } from './GlassLanguageSelect';
import type { IpaCoreBridge } from '@/hooks/useAltroCore';

const TYPE_BORDER_COLORS: Record<string, string> = {
  money: '#4AF626',
  percent: '#F6E026',
  date: '#2684F6',
  daterange: '#2684F6',
  timeref: '#f472b6',
  number: '#a78bfa',
};

/** Matches `{{IPA_N}}` or Double OPR `{{IPA_N: preview}}`. */
const IPA_REGEX = /\{\{\s*IPA_(\d+)(?:\s*:\s*[^}]*)?\s*\}\}/g;

export interface StencilMonitorProps {
  isDark?: boolean;
  /** Трафарет: текст с метками {{IPA_N}} */
  maskedText?: string;
  /** Маппинг IPA_N → тип для цвета рамки */
  ipaToEntity?: Array<{ ipaId: number; type: string }>;
  /** При наведении на блок — вызывается с IPA id */
  onHoverIPA?: (ipaId: number | null) => void;
  /** Сырой текст терминала для IPA Capture */
  sourceTextForCapture?: string;
  /** Синхронизация Command Bar → родитель (transcreate userIntent) */
  onSyncCommandIntent?: (intent: string) => void;
  /** Ядро ALTRO 1 (один экземпляр с page) */
  ipa: IpaCoreBridge;
  /** Разрешённая цель трафарета при режиме AUTO (подсказка в селекторе) */
  stencilResolvedTarget?: string;
}

/** Блок [ID: N] с цветной рамкой по типу */
function StencilBlock({
  ipaId,
  type,
  isDark,
  onMouseEnter,
  onMouseLeave,
}: {
  ipaId: number;
  type: string;
  isDark: boolean;
  onMouseEnter: () => void;
  onMouseLeave: () => void;
}) {
  const [showTooltip, setShowTooltip] = useState(false);
  const borderColor = TYPE_BORDER_COLORS[type] ?? '#6b7280';
  const blockBg = isDark ? '#111' : '#d1d5db';

  return (
    <span
      className="inline-flex items-center align-baseline mx-0.5"
      onMouseEnter={() => {
        onMouseEnter();
        setShowTooltip(true);
      }}
      onMouseLeave={() => {
        onMouseLeave();
        setShowTooltip(false);
      }}
      style={{ position: 'relative' }}
    >
      <span
        className="inline-block px-1.5 py-0.5 rounded cursor-default text-[10px] font-mono"
        style={{
          border: `1px solid ${borderColor}`,
          color: borderColor,
          background: blockBg,
        }}
      >
        [ID: {ipaId}]
      </span>
      {showTooltip && (
        <span
          className="absolute z-50 left-1/2 -translate-x-1/2 -top-7 px-2 py-1 rounded text-[9px] font-mono whitespace-nowrap"
          style={{
            background: '#222',
            border: '1px solid #333',
            color: '#9ca3af',
            boxShadow: '0 2px 8px rgba(0,0,0,0.4)',
          }}
        >
          SECURED IN VAULT
        </span>
      )}
    </span>
  );
}

const PANEL_THEME = {
  dark: { bg: '#1A1A1B', border: '#333', contentBg: '#111', text: '#e5e7eb', waiting: '#4b5563' },
  light: { bg: '#F5F5F5', border: '#d1d5db', contentBg: '#e5e7eb', text: '#1A1A1B', waiting: '#6b7280' },
};

/** Центральная панель: трафарет с блоками [ID: N]. */
export function StencilMonitor({
  isDark = true,
  maskedText = '',
  ipaToEntity = [],
  onHoverIPA,
  sourceTextForCapture = '',
  onSyncCommandIntent,
  ipa,
  stencilResolvedTarget,
}: StencilMonitorProps) {
  const t = PANEL_THEME[isDark ? 'dark' : 'light'];
  const ipaTypeMap = useMemo(() => {
    const m = new Map<number, string>();
    for (const { ipaId, type } of ipaToEntity) {
      m.set(ipaId, type);
    }
    return m;
  }, [ipaToEntity]);

  const parts = useMemo(() => {
    if (!maskedText.trim()) return null;

    const result: Array<{ key: string; type: 'text' | 'ipa'; content?: string; ipaId?: number }> = [];
    let lastIndex = 0;
    let match: RegExpExecArray | null;

    IPA_REGEX.lastIndex = 0;
    while ((match = IPA_REGEX.exec(maskedText)) !== null) {
      if (match.index > lastIndex) {
        result.push({
          key: `t-${lastIndex}`,
          type: 'text',
          content: maskedText.slice(lastIndex, match.index),
        });
      }
      const ipaId = parseInt(match[1], 10);
      result.push({ key: `ipa-${ipaId}`, type: 'ipa', ipaId });
      lastIndex = match.index + match[0].length;
    }
    if (lastIndex < maskedText.length) {
      result.push({ key: `t-${lastIndex}`, type: 'text', content: maskedText.slice(lastIndex) });
    }

    return result;
  }, [maskedText]);

  const isEmpty = !maskedText?.trim();

  return (
    <div
      className="flex flex-col h-full min-h-0 overflow-hidden font-mono"
      style={{ background: t.bg, borderRight: `1px solid ${t.border}` }}
    >
      <div
        className="flex-shrink-0 px-3 py-2 flex items-center justify-between gap-2 text-[10px] uppercase tracking-widest"
        style={{ color: t.waiting, borderBottom: `1px solid ${t.border}` }}
      >
        <span>Монитор Трафарета</span>
        <GlassLanguageSelect
          isDark={isDark}
          variant="languages"
          label="STENCIL"
          value={ipa.stencilLanguageMode}
          onChange={ipa.setStencilLanguageMode}
          resolvedHint={ipa.stencilLanguageMode === 'AUTO' ? stencilResolvedTarget ?? null : null}
          title="Язык трафарета (targetLanguage): AUTO — resolveTargetLanguage + источник; иначе фиксированный код"
        />
      </div>

      <CommandBar
        isDark={isDark}
        ipa={ipa}
        sourceTextCapture={sourceTextForCapture}
        onSyncCommandIntent={onSyncCommandIntent}
      />

      <div
        className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden p-3 text-[11px] leading-relaxed"
        style={{ color: t.text, background: t.contentBg }}
      >
        {isEmpty ? (
          <span style={{ color: t.waiting, fontStyle: 'italic' }}>
            [WAITING FOR DATA STRUCTURE...]
          </span>
        ) : parts ? (
          <>
            {parts.map((p) =>
              p.type === 'text' ? (
                <span key={p.key}>{p.content}</span>
              ) : (
                <StencilBlock
                  key={p.key}
                  ipaId={p.ipaId!}
                  type={ipaTypeMap.get(p.ipaId!) ?? 'unknown'}
                  isDark={isDark}
                  onMouseEnter={() => onHoverIPA?.(p.ipaId!)}
                  onMouseLeave={() => onHoverIPA?.(null)}
                />
              )
            )}
          </>
        ) : null}
      </div>
    </div>
  );
}
