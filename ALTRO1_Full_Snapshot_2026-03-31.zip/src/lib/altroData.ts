/* MIT License | Copyright (c) 2026 SERGEI NAZARIAN (SVN) | ALTRO: Semantic Orchestration Layer */

/**
 * ALTRO Data Layer — Словарь и веса доменов
 * Содержит ALTRO_LIBRARY (словарь трансформаций) и константы для доменов
 */

import type { ExternalDomainKey, InternalDomainKey } from '@/lib/altro/foundation';

/** Тип для доменных весов (13 доменов) */
export type DomainWeights = {
  // External (8)
  economics: number;
  politics: number;
  society: number;
  history: number;
  culture: number;
  aesthetics: number;
  technology: number;
  spirituality: number;
  // Internal (5)
  semantics: number;
  context: number;
  intent: number;
  imagery: number;
  ethics: number;
};

/** Словарь Истины (ALTRO_LIBRARY): варианты слов для разных доменов с порогами активации и грамматическим родом */
export const ALTRO_LIBRARY: Record<string, Partial<Record<'imagery' | 'ethics' | 'context' | 'intent' | 'semantics' | 'semantic' | 'sacred' | 'history' | 'aesthetics' | 'culture' | 'politics' | 'economics' | 'technology', { text: string; threshold: number; gender: 'm' | 'f' | 'n' }>>> = {
  'встреча': {
    imagery: { text: 'знак, подаренный судьбой', threshold: 0.1, gender: 'm' },
    intent: { text: 'долгожданное событие', threshold: 0.4, gender: 'n' },
    ethics: { text: 'священная встреча', threshold: 0.3, gender: 'f' },
    context: { text: 'событие в календаре', threshold: 0.2, gender: 'n' },
    semantics: { text: 'синхронизация узлов', threshold: 0.2, gender: 'f' },
    politics: { text: 'дипломатический контакт', threshold: 0.2, gender: 'm' },
    economics: { text: 'синергетический эффект', threshold: 0.2, gender: 'm' },
    technology: { text: 'синергетический эффект', threshold: 0.2, gender: 'm' },
    culture: { text: 'культурный резонанс', threshold: 0.2, gender: 'm' },
  },
  'папа': {
    history: { text: 'Отец (чей путь был подвигом)', threshold: 0.2, gender: 'm' },
    semantics: { text: 'Глава рода', threshold: 0.5, gender: 'm' },
    ethics: { text: 'Отец (чей путь был подвигом)', threshold: 0.3, gender: 'm' },
  },
  'мама': {
    history: { text: 'Мама (источник света)', threshold: 0.2, gender: 'f' },
    semantics: { text: 'Мама (источник света)', threshold: 0.5, gender: 'f' },
    ethics: { text: 'Мама (источник света)', threshold: 0.3, gender: 'f' },
  },
  'ростов': {
    history: { text: 'Родной город на Дону', threshold: 0.2, gender: 'm' },
    context: { text: 'южная столица', threshold: 0.4, gender: 'f' },
    semantics: { text: 'Родной город на Дону', threshold: 0.3, gender: 'm' },
  },
  'ростове-на-дону': {
    history: { text: 'Родном городе на Дону', threshold: 0.2, gender: 'm' },
    context: { text: 'южной столице', threshold: 0.4, gender: 'f' },
  },
  'дорога': {
    semantic: { text: 'путь пройденный во времени', threshold: 0.2, gender: 'm' },
    context: { text: 'путь', threshold: 0.2, gender: 'm' },
    intent: { text: 'дорога к дому', threshold: 0.3, gender: 'f' },
    imagery: { text: 'путь, вымощенный судьбой', threshold: 0.1, gender: 'm' },
    sacred: { text: 'путь пройденный во времени', threshold: 0.2, gender: 'm' },
  },
  'дом': {
    semantic: { text: 'пристанище души', threshold: 0.2, gender: 'n' },
    context: { text: 'место обитания', threshold: 0.2, gender: 'n' },
    intent: { text: 'убежище от мира', threshold: 0.3, gender: 'n' },
    imagery: { text: 'крепость памяти', threshold: 0.1, gender: 'f' },
    sacred: { text: 'пристанище души', threshold: 0.2, gender: 'n' },
  },
  'голос': {
    semantic: { text: 'эхо истины', threshold: 0.2, gender: 'n' },
    context: { text: 'звук речи', threshold: 0.2, gender: 'm' },
    intent: { text: 'призыв к действию', threshold: 0.3, gender: 'm' },
    imagery: { text: 'вибрация смысла', threshold: 0.1, gender: 'f' },
    sacred: { text: 'эхо истины', threshold: 0.2, gender: 'n' },
  },
  'граница': {
    semantic: { text: 'порог между мирами', threshold: 0.2, gender: 'm' },
    context: { text: 'линия раздела', threshold: 0.2, gender: 'f' },
    intent: { text: 'предел возможного', threshold: 0.3, gender: 'm' },
    imagery: { text: 'черта судьбы', threshold: 0.1, gender: 'f' },
    sacred: { text: 'порог между мирами', threshold: 0.2, gender: 'm' },
  },
  'свет': {
    semantic: { text: 'источник знания', threshold: 0.2, gender: 'm' },
    context: { text: 'освещение', threshold: 0.2, gender: 'n' },
    intent: { text: 'путеводная звезда', threshold: 0.3, gender: 'f' },
    imagery: { text: 'Свет истины', threshold: 0.1, gender: 'm' },
    sacred: { text: 'Свет истины. Свет знаний. Тьма не накроет свет.', threshold: 0.2, gender: 'm' },
  },
  'память': {
    semantic: { text: 'хранилище опыта', threshold: 0.2, gender: 'n' },
    context: { text: 'воспоминание', threshold: 0.2, gender: 'n' },
    intent: { text: 'связь с прошлым', threshold: 0.3, gender: 'f' },
    imagery: { text: 'книга жизни', threshold: 0.1, gender: 'f' },
    sacred: { text: 'хранилище опыта', threshold: 0.2, gender: 'n' },
  },
  'дело': {
    semantic: { text: 'миссия предназначения', threshold: 0.2, gender: 'f' },
    context: { text: 'занятие', threshold: 0.2, gender: 'n' },
    intent: { text: 'цель существования', threshold: 0.3, gender: 'f' },
    imagery: { text: 'нить бытия', threshold: 0.1, gender: 'f' },
    sacred: { text: 'миссия предназначения', threshold: 0.2, gender: 'f' },
  },
  'кошка': {
    semantic: { text: 'хранительница тайн', threshold: 0.2, gender: 'f' },
    context: { text: 'домашнее животное', threshold: 0.2, gender: 'n' },
    intent: { text: 'спутник одиночества', threshold: 0.3, gender: 'm' },
    imagery: { text: 'тень мудрости', threshold: 0.1, gender: 'f' },
    sacred: { text: 'хранительница тайн', threshold: 0.2, gender: 'f' },
  },
  'судьба': {
    imagery: { text: 'священный чертеж бытия', threshold: 0.1, gender: 'm' },
    ethics: { text: 'неизбежный свет пути', threshold: 0.3, gender: 'm' },
    semantics: { text: 'целевой вектор', threshold: 0.2, gender: 'm' },
    intent: { text: 'неодолимого страсти желанье', threshold: 0.4, gender: 'n' },
  },
  'время': {
    imagery: { text: 'песок в часах вечности', threshold: 0.1, gender: 'm' },
    history: { text: 'свидетель наших дел', threshold: 0.2, gender: 'm' },
  },
  'слово': {
    ethics: { text: 'инструмент созидания', threshold: 0.3, gender: 'm' },
    imagery: { text: 'пульс мысли', threshold: 0.1, gender: 'm' },
  },
};

/** Начальные веса доменов (все 0) */
export const INITIAL_DOMAIN_WEIGHTS: DomainWeights = {
  economics: 0,
  politics: 0,
  society: 0,
  history: 0,
  culture: 0,
  aesthetics: 0,
  technology: 0,
  spirituality: 0,
  semantics: 0,
  context: 0,
  intent: 0,
  imagery: 0,
  ethics: 0,
};

/** Лейблы для внешних доменов (на русском) */
export const EXTERNAL_DOMAIN_LABELS: Record<ExternalDomainKey, string> = {
  economics: 'Экономика',
  politics: 'Политика',
  society: 'Общество',
  history: 'История',
  culture: 'Культура',
  aesthetics: 'Эстетика',
  technology: 'Технологии',
  spirituality: 'Духовность',
};

/** Лейблы для внутренних доменов (на русском) */
export const INTERNAL_DOMAIN_LABELS: Record<InternalDomainKey, string> = {
  semantics: 'Семантика',
  context: 'Контекст',
  intent: 'Намерение',
  imagery: 'Образность',
  ethics: 'Этика & Сакральное',
};

export const INTERNAL_BAR_COLOR = '#10b981'; // изумрудный

/** Массив ключей внешних доменов */
export const EXTERNAL_DOMAIN_KEYS: ExternalDomainKey[] = ['economics', 'politics', 'society', 'history', 'culture', 'aesthetics', 'technology', 'spirituality'];

/** Массив ключей внутренних доменов */
export const INTERNAL_DOMAIN_KEYS: InternalDomainKey[] = ['semantics', 'context', 'intent', 'imagery', 'ethics'];

/** DOMAIN_MATRIX: Базовые веса для 8 внешних доменов по сценариям */
export type ScenarioType = 'technocrat' | 'poetics' | 'sacred' | 'slang' | 'without' | 'goldStandard';

export interface ScenarioWeights {
  economics: number;
  politics: number;
  society: number;
  history: number;
  culture: number;
  aesthetics: number;
  technology: number;
  spirituality: number;
}

export const DOMAIN_MATRIX: Record<ScenarioType, ScenarioWeights> = {
  technocrat: {
    // External: Econ=0.6, Pol=0.2, Soc=0.4, Hist=-0.2, Cult=-0.4, Aes=-0.8, Tech=1.0, Rel=-0.8
    // Преобразование из -1..1 в 0..1: x = (value + 1) / 2
    economics: (0.6 + 1) / 2,      // 0.8
    politics: (0.2 + 1) / 2,        // 0.6
    society: (0.4 + 1) / 2,        // 0.7
    history: (-0.2 + 1) / 2,       // 0.4
    culture: (-0.4 + 1) / 2,       // 0.3
    aesthetics: (-0.8 + 1) / 2,    // 0.1
    technology: (1.0 + 1) / 2,     // 1.0
    spirituality: (-0.8 + 1) / 2,      // 0.1
  },
  poetics: {
    // External: Econ=-0.6, Pol=-0.4, Soc=-0.2, Hist=0.2, Cult=0.8, Aes=1.0, Tech=-0.6, Rel=0.0
    economics: (-0.6 + 1) / 2,      // 0.2
    politics: (-0.4 + 1) / 2,      // 0.3
    society: (-0.2 + 1) / 2,      // 0.4
    history: (0.2 + 1) / 2,       // 0.6
    culture: (0.8 + 1) / 2,       // 0.9
    aesthetics: (1.0 + 1) / 2,    // 1.0
    technology: (-0.6 + 1) / 2,    // 0.2
    spirituality: (0.0 + 1) / 2,       // 0.5
  },
  sacred: {
    // External: Econ=-0.8, Pol=-0.6, Soc=-0.4, Hist=0.6, Cult=0.4, Aes=0.8, Tech=-0.8, Rel=1.0
    economics: (-0.8 + 1) / 2,     // 0.1
    politics: (-0.6 + 1) / 2,      // 0.2
    society: (-0.4 + 1) / 2,      // 0.3
    history: (0.6 + 1) / 2,       // 0.8
    culture: (0.4 + 1) / 2,       // 0.7
    aesthetics: (0.8 + 1) / 2,     // 0.9
    technology: (-0.8 + 1) / 2,    // 0.1
    spirituality: (1.0 + 1) / 2,      // 1.0
  },
  slang: {
    economics: 0.6,
    politics: 0.5,
    society: 0.8,
    history: 0.2,
    culture: 0.7,
    aesthetics: 0.3,
    technology: 0.5,
    spirituality: 0.2,
  },
  without: {
    economics: 0,
    politics: 0,
    society: 0,
    history: 0,
    culture: 0,
    aesthetics: 0,
    technology: 0,
    spirituality: 0,
  },
  goldStandard: {
    economics: 0,
    politics: 0,
    society: 0,
    history: 0,
    culture: 0.7,
    aesthetics: 0.5,
    technology: 0.3,
    spirituality: 0,
  },
};

/** SCENARIO_PROFILES: Профили сценариев с весами для 8 доменов (0.0 - 1.0) */
export interface ScenarioProfile {
  economics: number;
  politics: number;
  society: number;
  history: number;
  culture: number;
  aesthetics: number;
  technology: number;
  spirituality: number;
}

export const SCENARIO_PROFILES: Record<ScenarioType, ScenarioProfile> = {
  technocrat: {
    // External: Econ=0.6, Pol=0.2, Soc=0.4, Hist=-0.2, Cult=-0.4, Aes=-0.8, Tech=1.0, Rel=-0.8
    economics: (0.6 + 1) / 2,      // 0.8
    politics: (0.2 + 1) / 2,        // 0.6
    society: (0.4 + 1) / 2,        // 0.7
    history: (-0.2 + 1) / 2,       // 0.4
    culture: (-0.4 + 1) / 2,       // 0.3
    aesthetics: (-0.8 + 1) / 2,    // 0.1
    technology: (1.0 + 1) / 2,     // 1.0
    spirituality: (-0.8 + 1) / 2,      // 0.1
  },
  poetics: {
    // External: Econ=-0.6, Pol=-0.4, Soc=-0.2, Hist=0.2, Cult=0.8, Aes=1.0, Tech=-0.6, Rel=0.0
    economics: (-0.6 + 1) / 2,      // 0.2
    politics: (-0.4 + 1) / 2,      // 0.3
    society: (-0.2 + 1) / 2,      // 0.4
    history: (0.2 + 1) / 2,       // 0.6
    culture: (0.8 + 1) / 2,       // 0.9
    aesthetics: (1.0 + 1) / 2,    // 1.0
    technology: (-0.6 + 1) / 2,    // 0.2
    spirituality: (0.0 + 1) / 2,       // 0.5
  },
  sacred: {
    // External: Econ=-0.8, Pol=-0.6, Soc=-0.4, Hist=0.6, Cult=0.4, Aes=0.8, Tech=-0.8, Rel=1.0
    economics: (-0.8 + 1) / 2,     // 0.1
    politics: (-0.6 + 1) / 2,      // 0.2
    society: (-0.4 + 1) / 2,      // 0.3
    history: (0.6 + 1) / 2,       // 0.8
    culture: (0.4 + 1) / 2,       // 0.7
    aesthetics: (0.8 + 1) / 2,     // 0.9
    technology: (-0.8 + 1) / 2,    // 0.1
    spirituality: (1.0 + 1) / 2,      // 1.0
  },
  slang: {
    economics: 0.6,
    politics: 0.5,
    society: 0.8,
    history: 0.2,
    culture: 0.7,
    aesthetics: 0.3,
    technology: 0.5,
    spirituality: 0.2,
  },
  without: {
    economics: 0.0,
    politics: 0.0,
    society: 0.0,
    history: 0.0,
    culture: 0.0,
    aesthetics: 0.0,
    technology: 0.0,
    spirituality: 0.0,
  },
  goldStandard: {
    economics: 0.0,
    politics: 0.0,
    society: 0.0,
    history: 0.0,
    culture: 0.7,
    aesthetics: 0.5,
    technology: 0.3,
    spirituality: 0.0,
  },
};

/** SCENARIO_UI_WEIGHTS: Полные веса для UI (слайдеры перемещаются при выборе сценария). External: -1..1, Internal: 0..1. */
export const SCENARIO_UI_WEIGHTS: Record<ScenarioType, DomainWeights> = {
  technocrat: {
    ...INITIAL_DOMAIN_WEIGHTS,
    economics: 0.6,
    politics: 0.2,
    society: 0.4,
    history: -0.2,
    culture: -0.4,
    aesthetics: -0.8,
    technology: 1.0,
    spirituality: -0.8,
  },
  poetics: {
    ...INITIAL_DOMAIN_WEIGHTS,
    economics: -0.6,
    politics: -0.4,
    society: -0.2,
    history: 0.2,
    culture: 0.8,
    aesthetics: 1.0,
    technology: -0.6,
    spirituality: 0.0,
  },
  sacred: {
    ...INITIAL_DOMAIN_WEIGHTS,
    economics: -0.8,
    politics: -0.6,
    society: -0.4,
    history: 0.6,
    culture: 0.4,
    aesthetics: 0.8,
    technology: -0.8,
    spirituality: 1.0,
  },
  slang: {
    ...INITIAL_DOMAIN_WEIGHTS,
    economics: 0.2,
    politics: 0.0,
    society: 0.6,
    history: -0.6,
    culture: 0.4,
    aesthetics: -0.4,
    technology: 0.0,
    spirituality: -0.6,
  },
  without: {
    ...INITIAL_DOMAIN_WEIGHTS,
  },
  goldStandard: {
    economics: 0,
    politics: 0,
    society: 0,
    history: 0,
    culture: 0.7,
    aesthetics: 0.5,
    technology: 0.3,
    spirituality: 0,
    semantics: 0.85,
    context: 0.75,
    intent: 0.62,
    imagery: 0.45,
    ethics: 0.9,
  },
};

/** Словарь омонимов для Synchronizer Lingua */
export const HOMONYM_WORDS = [
  'замок',    // замок (крепость) / замок (запор)
  'ключ',     // ключ (инструмент) / ключ (источник)
  'коса',     // коса (волосы) / коса (инструмент) / коса (отмель)
  'косой',    // косой (инструмент/причёска/взгляд/геометрический)
  'лук',      // лук (оружие) / лук (овощ)
  'мир',      // мир (вселенная) / мир (покой)
  'мука',     // мука (страдание) / мука (продукт)
  'атлас',    // атлас (карты) / атлас (ткань)
  'повод',    // повод (причина) / повод (упряжь)
  'органы',   // органы (инструменты) / органы (тела)
  'дела',     // дела (поступки) / дела (занятия)
  'стоит',    // сто́ит (стоять) / стои́т (стоить)
];

/** HOMONYM_DB: База данных омонимов с вариантами ударений и их значениями */
export interface HomonymVariant {
  /** Слово с ударением (Unicode \u0301) */
  word: string;
  /** Значение/толкование */
  meaning: string;
  /** Опциональная категория (geometric и т.д.) */
  category?: string;
}

export interface HomonymEntry {
  /** Базовое слово без ударения */
  base: string;
  /** Варианты с ударениями */
  variants: HomonymVariant[];
}

/** Словоформы омонимов: форма -> базовая форма (для морфологического поиска). Склонения: замок, замка, замке и т.д. */
export const HOMONYM_WORD_FORMS: Record<string, string> = {
  'замок': 'замок', 'замка': 'замок', 'замку': 'замок', 'замком': 'замок', 'замке': 'замок', 'замки': 'замок', 'замков': 'замок', 'замкам': 'замок', 'замками': 'замок', 'замках': 'замок',
  'мука': 'мука', 'муки': 'мука', 'муку': 'мука', 'мукой': 'мука', 'муке': 'мука',
  'орган': 'орган', 'органа': 'орган', 'органу': 'орган', 'органом': 'орган', 'органе': 'орган', 'органы': 'орган', 'органов': 'орган', 'органам': 'орган', 'органами': 'орган', 'органах': 'орган',
  'стоит': 'стоит', 'стоило': 'стоит', 'стоила': 'стоит', 'стоили': 'стоит',
  'дела': 'дела', 'дел': 'дела', 'делом': 'дела', 'деле': 'дела',
  'дорога': 'дорога', 'дороги': 'дорога', 'дорогу': 'дорога', 'дорогой': 'дорога', 'дороге': 'дорога', 'дорог': 'дорога',
  'повод': 'повод', 'повода': 'повод', 'поводу': 'повод', 'поводом': 'повод', 'поводе': 'повод', 'поводы': 'повод',
  'атлас': 'атлас', 'атласа': 'атлас', 'атласу': 'атлас', 'атласом': 'атлас', 'атласе': 'атлас', 'атласы': 'атлас',
  'засыпать': 'засыпать', 'засыпаю': 'засыпать', 'засыпаешь': 'засыпать', 'засыпает': 'засыпать', 'засыпаем': 'засыпать', 'засыпаете': 'засыпать', 'засыпают': 'засыпать', 'засыпал': 'засыпать', 'засыпала': 'засыпать', 'засыпало': 'засыпать', 'засыпали': 'засыпать',
  'косой': 'косой', 'косого': 'косой', 'косому': 'косой', 'косым': 'косой', 'косом': 'косой', 'косая': 'косой', 'косую': 'косой', 'косою': 'косой', 'косое': 'косой', 'косые': 'косой', 'косых': 'косой', 'косыми': 'косой',
};

export const HOMONYM_DB: HomonymEntry[] = [
  {
    base: 'замок',
    variants: [
      { word: 'за\u0301мок', meaning: 'строение' },
      { word: 'замо\u0301к', meaning: 'запор, устройство для закрытия' },
    ],
  },
  {
    base: 'мука',
    variants: [
      { word: 'му\u0301ка', meaning: 'страдание, мучение' },
      { word: 'мука\u0301', meaning: 'продукт перемола зерна' },
    ],
  },
  {
    base: 'орган',
    variants: [
      { word: 'о\u0301рган', meaning: 'музыкальный инструмент' },
      { word: 'орга\u0301н', meaning: 'часть тела, орган организма' },
    ],
  },
  {
    base: 'стоит',
    variants: [
      { word: 'сто\u0301ит', meaning: 'стоять (вертикально)' },
      { word: 'стои\u0301т', meaning: 'стоить (цена)' },
    ],
  },
  {
    base: 'дела',
    variants: [
      { word: 'де\u0301ла', meaning: 'поступки, деяния' },
      { word: 'дела\u0301', meaning: 'занятия, работы' },
    ],
  },
  {
    base: 'дорога',
    variants: [
      { word: 'доро\u0301га', meaning: 'путь' },
      { word: 'дорога\u0301', meaning: 'дешевизна' },
    ],
  },
  {
    base: 'повод',
    variants: [
      { word: 'по\u0301вод', meaning: 'основание, причина' },
      { word: 'пово\u0301д', meaning: 'упряжь' },
    ],
  },
  {
    base: 'атлас',
    variants: [
      { word: 'а\u0301тлас', meaning: 'сборник карт' },
      { word: 'атла\u0301с', meaning: 'ткань' },
    ],
  },
  {
    base: 'засыпать',
    variants: [
      { word: 'засы\u0301пать', meaning: 'покрывать сыпучим (песком и т.д.)' },
      { word: 'засыпа\u0301ть', meaning: 'погружаться в сон' },
    ],
  },
  {
    base: 'дорог',
    variants: [
      { word: 'доро\u0301г', meaning: 'дороги (мн.ч. род.пад.)' },
      { word: 'доро\u0301г', meaning: 'дорогой (кратк. форма)' },
    ],
  },
  {
    base: 'косой',
    variants: [
      { word: 'косо\u0301й', meaning: 'инструмент' },
      { word: 'косо\u0301й', meaning: 'причёска' },
      { word: 'ко\u0301сой', meaning: 'взгляд' },
      { word: 'ко\u0301сой', meaning: 'Атрибут: неровный, под углом, кривой', category: 'geometric' },
    ],
  },
];

/** Базовый словарь для проверки орфографии (известные слова из ALTRO_LIBRARY и HOMONYM_DB) */
export const SPELLCHECK_DICTIONARY: Set<string> = new Set([
  // Слова из ALTRO_LIBRARY
  'встреча', 'встретились', 'папа', 'мама', 'и', 'имама',
  // Базовые формы омонимов
  'замок', 'мука', 'орган', 'стоит',
  // Другие распространенные слова
  'отец', 'мать', 'семья', 'дом', 'мир', 'путь', 'свет', 'источник',
  'в', 'красноярске', 'красноярск',
  // Расширенный словарь для Deep Spellcheck
  'звучит', 'звучал', 'звучала', 'звучало', 'звучали',
  'крепость', 'крепости', 'крепостью', 'крепостей',
  'вибрация', 'вибрации', 'вибрацией', 'вибраций',
  'мой', 'моя', 'мое', 'мои', 'мою', 'моим', 'моей', 'моих', 'моими',
  'твой', 'твоя', 'твое', 'твои', 'твою', 'твоим', 'твоей', 'твоих', 'твоими',
  'наш', 'наша', 'наше', 'наши', 'нашего', 'нашей', 'наших', 'нашими',
  'ваш', 'ваша', 'ваше', 'ваши', 'вашего', 'вашей', 'ваших', 'вашими',
]);

/** Словарь исправлений орфографии (ошибка -> правильное слово). Топонимы: приоритет домена Контекст. */
export const SPELLCHECK_CORRECTIONS: Record<string, string> = {
  'встетились': 'встретились',
  'красносрске': 'Красноярске',
  'Красносрске': 'Красноярске',
  'вКрасноярске': 'в Красноярске',
  'вкрасноярске': 'в Красноярске',
  'вкрасносрске': 'в Красноярске',
  'вКрасносрске': 'в Красноярске',
  'звусит': 'звучит',
  'звуси': 'звучит',
  'звусил': 'звучал',
  'звусила': 'звучала',
  'звусило': 'звучало',
  'твоц': 'твой', // Исправление опечатки "твоц" -> "твой" (в начале строки или в любом месте)
};

/** Известные имена собственные и топонимы (не проверяются на орфографию) */
export const PROPER_NOUNS: Set<string> = new Set([
  'Иван', 'Мария', 'Петр', 'Анна', 'Сергей', 'Елена',
  'Красноярск', 'Красноярске', 'Красноярска',
]);

/** Варианты уточнения для омографов (при клике на подсвеченный омоним в тексте). */
export const CLARIFICATION_OPTIONS: Record<string, { label: string; value: string }[]> = {
  поводу: [
    { label: 'по́воду (основание)', value: 'по\u0301воду' },
    { label: 'поводу́ (упряжь)', value: 'поводу\u0301' },
  ],
  органы: [
    { label: 'о́рганы (инструменты)', value: 'о\u0301рганы' },
    { label: 'органы́ (тела)', value: 'органы\u0301' },
  ],
  принял: [
    { label: 'при́нял (взял)', value: 'при\u0301нял' },
    { label: 'приня́л (решение)', value: 'приня\u0301л' },
  ],
  дела: [
    { label: 'де́ла (поступки)', value: 'де\u0301ла' },
    { label: 'дела́ (занятия)', value: 'дела\u0301' },
  ],
  дорога: [
    { label: 'доро́га (путь)', value: 'доро\u0301га' },
    { label: 'дорога́ (дешевизна)', value: 'дорога\u0301' },
  ],
  замок: [
    { label: 'за́мок (строение)', value: 'за\u0301мок' },
    { label: 'замо́к (запор)', value: 'замо\u0301к' },
  ],
};
