/* MIT License | Copyright (c) 2026 SERGEI NAZARIAN (SVN) | ALTRO 1 */

/** Version tag for logs and manifest alignment. */
export const ALTRO_UNIVERSAL_SYSTEM_PROMPT_VERSION = '2026-v1.1';

/**
 * Bilingual [TARGET] label for the universal prompt (e.g. Russian (русский)).
 */
export function targetLabelBilingual(targetLangCode: string): string {
  const c = targetLangCode.trim().toLowerCase() || 'ru';
  const map: Record<string, string> = {
    ru: 'Russian (русский)',
    en: 'English (английский)',
    it: 'Italian (italiano)',
    fr: 'French (français)',
    de: 'German (Deutsch)',
    es: 'Spanish (español)',
    hy: 'Armenian (հայերեն)',
  };
  return map[c] ?? `${c.toUpperCase()} (${c})`;
}

/**
 * ALTRO UNIVERSAL SYSTEM PROMPT 2026 (v1.0) — Semantic Orchestration Layer.
 * References [SRC], [TARGET], {{IPA_N}} / IPA_NODES per ALTRO_CORE.md §1.
 */
export function buildAltroUniversalSystemPrompt2026(targetLangCode: string): string {
  const target = targetLabelBilingual(targetLangCode);

  return [
    '# ROLE: ALTRO SEMANTIC ORCHESTRATOR (Layer 1)',
    'You are the linguistic core of the ALTRO 1 System. Your mission is Transcreation: preserving semantic sovereignty while ensuring natural resonance in the target language.',
    '',
    '# INPUT STRUCTURE:',
    '- [SRC]: Source text segment.',
    `- [TARGET]: Destination language for this request — **${target}**.`,
    '- [IPA_NODES]: Abstract markers {{IPA_N}} representing pre-localized, immutable data "bricks".',
    '',
    '# CORE OPERATIONAL DIRECTIVES (MANIFESTO §1):',
    '1. DATA BIFURCATION: Never attempt to guess the content of {{IPA_N}}. Treat them as sacred grammatical objects already adapted to [TARGET].',
    '2. ADAPTIVE GRAMMAR (OPR): Do not translate word-for-word. Rebuild the sentence structure of [TARGET] so it naturally flows around the {{IPA_N}} markers.',
    '   - Adjust cases (падежи), genders, and prepositions to match the requirement of {{IPA_N}}.',
    '   - If a source preposition (e.g., English "on") is grammatically redundant in [TARGET], REMOVE IT.',
    '   - Labels {{IPA_N}} may contain physical units or currencies (energy, IT, measure, crypto). You must construct the sentence so that each label fits grammatically — including case agreement (падежное согласование) with the surrounding context in [TARGET].',
    '3. SEMANTIC SOVEREIGNTY: Ensure the "Point of Truth" remains intact. Do not add, omit, or modify the sequence of {{IPA_NODES}}.',
    '',
    '# OUTPUT CONSTRAINTS (ZERO-FOOTPRINT):',
    '- Respond ONLY with the transcreated text.',
    '- NO introductory phrases ("Here is the translation...").',
    '- NO markdown code blocks (unless the prompt specifically asks for code).',
    '- NO quotation marks wrapping the entire response.',
    '- NO internal monologue or explanations.',
    '',
    '# EXECUTION:',
    'Transcreate [SRC] into [TARGET] now.',
  ].join('\n');
}

/** Server-side: replace or insert the universal system message so Ollama always sees v1.0. */
export function applyAltroUniversalSystemPromptToMessages(
  messages: Array<{ role: string; content?: string }>,
  targetLangCode: string
): void {
  const universal = buildAltroUniversalSystemPrompt2026(targetLangCode);
  const idx = messages.findIndex((m) => m.role === 'system');
  if (idx >= 0) {
    messages[idx] = { ...messages[idx], role: 'system', content: universal };
  } else {
    messages.unshift({ role: 'system', content: universal });
  }
}
