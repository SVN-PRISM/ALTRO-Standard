/* MIT License | Copyright (c) 2026 SERGEI NAZARIAN (SVN) | ALTRO Stencil */

import { INITIAL_DOMAIN_WEIGHTS, type DomainWeights } from '@/lib/altroData';

/**
 * Keyword → домен: при совпадении подстроки в intent выставляется вес 1.0 (остальные — из базового профиля).
 * RU + EN для устойчивости к смешанным запросам.
 */
const INTENT_KEYWORD_RULES: ReadonlyArray<{
  keywords: readonly string[];
  domain: keyof DomainWeights;
}> = [
  {
    keywords: ['финансы', 'деньги', 'риск', 'finance', 'money', 'risk'],
    domain: 'economics',
  },
  {
    keywords: ['закон', 'договор', 'право', 'law', 'contract', 'legal'],
    domain: 'politics',
  },
  {
    keywords: ['душа', 'смысл', 'обитель', 'soul', 'meaning', 'abode'],
    domain: 'spirituality',
  },
];

/**
 * Автоматическое определение доменных весов по тексту намерения (command line / [USER_DIRECTIVE]).
 */
export function resolveWeightsFromIntent(intent: string): DomainWeights {
  const haystack = intent.trim().toLowerCase();
  const out: DomainWeights = { ...INITIAL_DOMAIN_WEIGHTS };

  if (!haystack) return out;

  for (const rule of INTENT_KEYWORD_RULES) {
    if (rule.keywords.some((kw) => haystack.includes(kw))) {
      out[rule.domain] = 1.0;
    }
  }

  return out;
}
