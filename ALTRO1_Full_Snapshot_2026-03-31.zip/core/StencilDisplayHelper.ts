/* MIT License | Copyright (c) 2026 SERGEI NAZARIAN (SVN) | ALTRO Stencil */

import { scanEntities, type EntityMatch } from './EntityScanner';

export interface StencilDisplayResult {
  maskedText: string;
  ipaToEntity: Array<{ ipaId: number; start: number; end: number; type: string }>;
}

/**
 * Строит трафарет из уже посчитанных сущностей (один вызов scanEntities на пайплайн).
 */
export function buildStencilFromEntities(sourceText: string, entities: EntityMatch[]): StencilDisplayResult {
  if (entities.length === 0) {
    return { maskedText: sourceText, ipaToEntity: [] };
  }

  let result = '';
  let pos = 0;
  const ipaToEntity: Array<{ ipaId: number; start: number; end: number; type: string }> = [];

  for (let i = 0; i < entities.length; i++) {
    const e = entities[i];
    const ipaId = i + 1;

    result += sourceText.slice(pos, e.start);
    result += `{{IPA_${ipaId}}}`;
    ipaToEntity.push({ ipaId, start: e.start, end: e.end, type: e.type });
    pos = e.end;
  }
  result += sourceText.slice(pos);

  return { maskedText: result, ipaToEntity };
}

/**
 * Строит трафарет для UI: заменяет сущности на [ID: N] в порядке позиции.
 */
export function buildStencilForDisplay(sourceText: string): StencilDisplayResult {
  const entities = scanEntities(sourceText);
  return buildStencilFromEntities(sourceText, entities);
}
