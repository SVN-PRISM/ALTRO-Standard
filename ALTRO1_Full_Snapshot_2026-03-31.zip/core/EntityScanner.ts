/* MIT License | Copyright (c) 2026 SERGEI NAZARIAN (SVN) | ALTRO Stencil */

/** Типы сущностей для подсветки и IPA */
export type EntityType =
  | 'money'
  | 'percent'
  | 'date'
  | 'daterange'
  | 'timeref'
  | 'number';

export interface EntityMatch {
  start: number;
  end: number;
  type: EntityType;
  text: string;
}

const CURRENCY_SYMBOLS = '(?:\\$|€|£|¥|₽|USD|EUR|GBP|RUB)';
const MAGNITUDE = '(?:billion|million|trillion|bn|bln|m|mn|mln|млрд|млн|трлн)';

/** Кварталы, FY/CY + Q, порядковые даты (англ.), квартал по-русски */
const TIME_REF_PATTERNS: Array<{ regex: RegExp; type: EntityType }> = [
  { regex: /\b(?:FY|CY)\s*20\d{2}\s*[-–]\s*Q[1-4]\b/gi, type: 'timeref' },
  { regex: /\bQ[1-4]\s*(?:20\d{2}|FY\s*20\d{2})?\b/gi, type: 'timeref' },
  { regex: /\bQ[1-4]\b/gi, type: 'timeref' },
  { regex: /\b[Кк]в\.?\s*[1-4](?:\s*20\d{2})?\b/g, type: 'timeref' },
  {
    regex: /\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2}(?:st|nd|rd|th),?\s+\d{4}\b/gi,
    type: 'timeref',
  },
  { regex: /\b\d{1,2}(?:st|nd|rd|th)\s+(?:of\s+)?(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\b/gi, type: 'timeref' },
  { regex: /\b(?:1st|2nd|3rd|\d{1,2}th)\b/gi, type: 'timeref' },
];

/**
 * Отдельно стоящие числа (450, 2027, 10.5, 1,000,000 с запятыми).
 * Запускается после денег/процентов/дат/timeref — пересечения отрезаются merge.
 */
const GENERIC_NUMBER_PATTERN: { regex: RegExp; type: EntityType } = {
  regex: /(?<![\d.])(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?(?![\d.])/g,
  type: 'number',
};

const PATTERNS: Array<{ regex: RegExp; type: EntityType }> = [
  { regex: new RegExp(`${CURRENCY_SYMBOLS}\\s*\\d+(?:\\.\\d+)?\\s*${MAGNITUDE}?`, 'gi'), type: 'money' },
  { regex: new RegExp(`\\d+(?:\\.\\d+)?\\s*${MAGNITUDE}`, 'gi'), type: 'money' },
  { regex: /\d+(?:\.\d+)?%/g, type: 'percent' },
  { regex: /\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2},?\s+\d{4}\b/gi, type: 'date' },
  { regex: /\d{2}\.\d{2}\.\d{4}/g, type: 'date' },
  { regex: /\d{4}-\d{2}-\d{2}/g, type: 'date' },
  { regex: /\d{4}-\d{4}/g, type: 'daterange' },
  ...TIME_REF_PATTERNS,
  GENERIC_NUMBER_PATTERN,
];

function collectMatches(text: string): EntityMatch[] {
  const matches: EntityMatch[] = [];

  for (const { regex, type } of PATTERNS) {
    const re = new RegExp(regex.source, regex.flags);
    let m: RegExpExecArray | null;
    while ((m = re.exec(text)) !== null) {
      matches.push({
        start: m.index,
        end: m.index + m[0].length,
        type,
        text: m[0],
      });
    }
  }

  matches.sort((a, b) => {
    if (a.start !== b.start) return a.start - b.start;
    return b.end - b.start - (a.end - a.start);
  });

  const filtered: EntityMatch[] = [];
  let lastEnd = -1;
  for (const m of matches) {
    if (m.start >= lastEnd) {
      filtered.push(m);
      lastEnd = m.end;
    }
  }
  return filtered;
}

/** Находит все сущности в тексте. При пересечении — приоритет более длинного совпадения с тем же start. */
export function scanEntities(text: string): EntityMatch[] {
  return collectMatches(text);
}
