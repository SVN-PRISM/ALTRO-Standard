/* MIT License | Copyright (c) 2026 SERGEI NAZARIAN (SVN) | ALTRO Stencil */

import type { DomainWeights } from '@/lib/altroData';
import type { DataVault } from './DataVault';
import {
  getMaskerUnitPatternSpecs,
  resolveUnitIdFromCapture,
  resolveUnitMagnetDisambiguation,
} from './dictionaries/UnitRegistry';
import { microTranscreate } from './microTranscreate';

/** Символы и коды валют: $ € £ ¥ ₽ USD EUR GBP RUB */
const CURRENCY_SYMBOLS = '(?:\\$|€|£|¥|₽|USD|EUR|GBP|RUB)';

/** Magnitude: без одиночного `m` (конфликт с метрами в Unit Magnet). */
const MAGNITUDE = '(?:billion|million|trillion|bn|bln|mn|mln|млрд|млн|трлн)';

/** Дробная часть: точка или запятой как десятичный разделитель (1.5 / 1,5). */
const DECIMAL_FRAC = '(?:[.,]\\d+)?';

/** Шаблоны (source + flags); Universal Unit Magnet — первыми (жадные фразы + число+единица). */
const PATTERN_SPECS: Array<{ source: string; flags: string; type: string }> = [
  ...getMaskerUnitPatternSpecs(DECIMAL_FRAC),
  {
    source: `${CURRENCY_SYMBOLS}\\s*\\d+${DECIMAL_FRAC}\\s*${MAGNITUDE}?`,
    flags: 'gi',
    type: 'money',
  },
  {
    source: `\\d+${DECIMAL_FRAC}\\s*${MAGNITUDE}`,
    flags: 'gi',
    type: 'money',
  },
  { source: String.raw`\d+${DECIMAL_FRAC}%`, flags: 'g', type: 'percent' },
  {
    source: String.raw`\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2},?\s+\d{4}\b`,
    flags: 'gi',
    type: 'date',
  },
  /** Month + day without year (mergeSpans prefers longer "Mar 28, 2024" when both match). */
  {
    source: String.raw`\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2}\b`,
    flags: 'gi',
    type: 'date',
  },
  { source: String.raw`\d{2}\.\d{2}\.\d{4}`, flags: 'g', type: 'date' },
  { source: String.raw`\d{4}-\d{2}-\d{2}`, flags: 'g', type: 'date' },
  { source: String.raw`\d{4}-\d{4}`, flags: 'g', type: 'daterange' },
];

/** Лимит итераций в `while (regex.exec)` — защита от бесконечного цикла при пустых совпадениях / багах RegExp. */
const MAX_REGEX_EXEC_ITER = 100;

interface RawSpan {
  start: number;
  end: number;
  text: string;
  type: string;
}

/**
 * Метки в ответе модели: `{{IPA_N}}` (промпт — голые) или редкий хвост `{{IPA_N: …}}`.
 */
export const IPA_LABEL_REGEX = /\{\{\s*IPA_(\d+)(?:\s*:\s*[^}]*)?\s*\}\}/g;

/**
 * Masker — Трафарет: извлекает сегменты, micro-transcreate в целевой язык,
 * в vault кладётся display (цель) + source (оригинал); в тексте — только {{IPA_N}}.
 * Один проход по тексту после слияния пересечений: без цепочки .replace по паттернам.
 */
export class Masker {
  constructor(private vault: DataVault) {}

  /**
   * Собирает все совпадения всех паттернов по исходному тексту.
   */
  private collectAllSpans(text: string): RawSpan[] {
    const spans: RawSpan[] = [];
    for (const spec of PATTERN_SPECS) {
      const re = new RegExp(spec.source, spec.flags);
      let m: RegExpExecArray | null;
      let execIter = 0;

      while ((m = re.exec(text)) !== null) {
        if (++execIter > MAX_REGEX_EXEC_ITER) {
          console.error(
            '[Masker] Safety: regex exec exceeded',
            MAX_REGEX_EXEC_ITER,
            'iterations for pattern type',
            spec.type
          );
          break;
        }
        const full = m[0];
        if (full.length === 0) {
          if (re.lastIndex === m.index) re.lastIndex++;
          continue;
        }
        spans.push({
          start: m.index,
          end: m.index + full.length,
          text: full,
          type: spec.type,
        });
      }
    }

    return spans;
  }

  /**
   * Убирает пересечения: сначала длинные спаны, затем жадно без наложений.
   */
  private mergeSpans(spans: RawSpan[]): RawSpan[] {
    const byLength = [...spans].sort((a, b) => b.end - b.start - (a.end - a.start));
    const selected: RawSpan[] = [];

    for (const s of byLength) {
      const overlaps = selected.some((x) => !(s.end <= x.start || s.start >= x.end));
      if (!overlaps) selected.push(s);
    }

    selected.sort((a, b) => a.start - b.start);
    return selected;
  }

  /**
   * Обрабатывает текст: совпадения собираются, сливаются по длине,
   * затем одним проходом подставляются временные блоки __ALTRO_IPA_BLOCK_*__ и финальные {{IPA_N}}.
   * @param targetLanguage — обязательный код цели (например `ru`) для Translation-First в vault.
   * @param weights — контекст доменов (IntentOrchestrator) для microTranscreate / будущих правил маскирования.
   */
  mask(text: string, targetLanguage: string, weights?: DomainWeights): string {
    const raw = this.collectAllSpans(text);
    const merged = this.mergeSpans(raw);

    const patternSpecsForLog = PATTERN_SPECS.map((spec) => ({
      type: spec.type,
      regexp: new RegExp(spec.source, spec.flags).toString(),
    }));
    console.log('[ALTRO][Masker] Спецификации RegExp (шаблоны Masker):', patternSpecsForLog);
    console.log(
      '[ALTRO][Masker] Совпадения по всем паттернам (до merge):',
      raw.map((s) => ({ type: s.type, start: s.start, end: s.end, captured: s.text }))
    );
    console.log(
      '[ALTRO][Masker] Итоговые захваты после merge (что ушло в трафарет):',
      merged.map((s) => ({ type: s.type, start: s.start, end: s.end, captured: s.text }))
    );

    const originals: Array<{ text: string; type: string }> = [];
    let out = '';
    let pos = 0;

    for (const s of merged) {
      out += text.slice(pos, s.start);
      const idx = originals.length;
      const token = `__ALTRO_IPA_BLOCK_${String(idx).padStart(6, '0')}__`;
      originals.push({ text: s.text.trim(), type: s.type });
      out += token;
      pos = s.end;
    }
    out += text.slice(pos);

    let finalOut = out;
    for (let i = 0; i < originals.length; i++) {
      const token = `__ALTRO_IPA_BLOCK_${String(i).padStart(6, '0')}__`;
      const source = originals[i].text;
      const detectedType = originals[i].type;
      if (detectedType === 'unit') {
        const uid = resolveUnitIdFromCapture(source);
        const dis = resolveUnitMagnetDisambiguation(source, uid);
        console.log(
          `[ALTRO][Stage:Unit-Magnet] Captured Unit: ${source} -> ID: ${uid ?? 'unknown'}${dis ? ` — ${dis}` : ''}`
        );
      }
      const display = microTranscreate(source, detectedType, targetLanguage, weights);
      if (process.env.ALTRO_AUDIT_STENCIL === '1') {
        console.log('[ALTRO_AUDIT][Masker] microTranscreate', {
          index: i,
          originalSegment: source,
          detectedType,
          targetLanguage,
          weightsContext: weights,
          microTranscreateResult: display,
        });
      }
      /** Vault хранит только результат microTranscreate(display); логи — только в console, не в IPA_NODE. */
      const key = this.vault.push(display, detectedType, source);
      if (!finalOut.includes(token)) continue;
      finalOut = finalOut.split(token).join(key);
    }

    return finalOut;
  }
}
