/* MIT License | Copyright (c) 2026 SERGEI NAZARIAN (SVN) | ALTRO Stencil */

import type { DomainWeights } from '@/lib/altroData';
import { localizeUnit, resolveUnitIdFromCapture } from './dictionaries/UnitRegistry';
import { parseDecimalNumericString } from './parseDecimalNumeric';

export { parseDecimalNumericString } from './parseDecimalNumeric';

/**
 * Micro-transcreation: dates, numbers, money, percent → target locale surface form.
 * Language-agnostic: driven by BCP-47–style codes (e.g. ru → ru-RU).
 * Optional `weights` — контекст IntentOrchestrator / доменов для тонкой настройки Intl.
 */

const LOCALE_BY_LANG: Record<string, string> = {
  ru: 'ru-RU',
  en: 'en-US',
  de: 'de-DE',
  fr: 'fr-FR',
  es: 'es-ES',
  it: 'it-IT',
  hy: 'hy-AM',
};

const CURRENCY_TOKEN =
  '(?:\\$|€|£|¥|₽|USD|EUR|GBP|RUB|JPY)';

const MAG_WORD =
  '(?:billion|million|trillion|bn|bln|mn|mln|млрд|млн|трлн)';

export function resolveLocaleTag(targetLanguage: string): string {
  const c = targetLanguage.trim().toLowerCase() || 'ru';
  if (LOCALE_BY_LANG[c]) return LOCALE_BY_LANG[c];
  if (/^[a-z]{2}-[A-Z]{2}$/.test(c)) return c;
  if (/^[a-z]{2}$/.test(c)) return `${c}-${c.toUpperCase()}`;
  return 'ru-RU';
}

function sanitizeForTagDisplay(s: string): string {
  return s
    .replace(/\r?\n/g, ' ')
    .replace(/\{\{/g, '«')
    .replace(/\}\}/g, '»')
    .replace(/\}/g, '')
    .replace(/\u{1F6E1}\uFE0F?/gu, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 160);
}

function parseDateLike(raw: string): Date | null {
  const v = raw.trim();
  const iso = /^(\d{4})-(\d{2})-(\d{2})$/.exec(v);
  if (iso) {
    const d = new Date(Date.UTC(+iso[1], +iso[2] - 1, +iso[3]));
    return Number.isNaN(d.getTime()) ? null : d;
  }
  const dmy = /^(\d{2})\.(\d{2})\.(\d{4})$/.exec(v);
  if (dmy) {
    const d = new Date(Date.UTC(+dmy[3], +dmy[2] - 1, +dmy[1]));
    return Number.isNaN(d.getTime()) ? null : d;
  }
  const enMonth =
    /\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+(\d{1,2}),?\s+(\d{4})\b/i.exec(v);
  if (enMonth) {
    const tryStr = `${enMonth[1]} ${enMonth[2]}, ${enMonth[3]}`;
    const d = new Date(tryStr);
    if (!Number.isNaN(d.getTime())) return d;
  }
  const enMonthNoYear =
    /\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+(\d{1,2})\b/i.exec(v);
  if (enMonthNoYear) {
    const y = new Date().getUTCFullYear();
    const tryStr = `${enMonthNoYear[1]} ${enMonthNoYear[2]}, ${y}`;
    const d = new Date(tryStr);
    if (!Number.isNaN(d.getTime())) return d;
  }
  const t = Date.parse(v);
  if (!Number.isNaN(t)) return new Date(t);
  return null;
}

function formatDate(d: Date, locale: string, weights?: DomainWeights): string {
  try {
    const opts: Intl.DateTimeFormatOptions = {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    };
    if (weights && weights.spirituality >= 0.5) {
      opts.weekday = 'long';
    }
    return new Intl.DateTimeFormat(locale, opts).format(d);
  } catch {
    return d.toISOString().slice(0, 10);
  }
}

function localizeDateRange(raw: string, locale: string): string {
  const v = raw.trim();
  const yr = /^(\d{4})\s*-\s*(\d{4})$/.exec(v);
  if (yr) {
    try {
      return new Intl.DateTimeFormat(locale, { year: 'numeric' }).format(new Date(+yr[1], 0, 1))
        + '–'
        + new Intl.DateTimeFormat(locale, { year: 'numeric' }).format(new Date(+yr[2], 0, 1));
    } catch {
      return v;
    }
  }
  const d = parseDateLike(v);
  return d ? formatDate(d, locale) : v;
}

function currencyCodeFromToken(t: string): string | undefined {
  const u = t.toUpperCase();
  const map: Record<string, string> = {
    $: 'USD',
    '€': 'EUR',
    '£': 'GBP',
    '¥': 'JPY',
    '₽': 'RUB',
    USD: 'USD',
    EUR: 'EUR',
    GBP: 'GBP',
    RUB: 'RUB',
    JPY: 'JPY',
  };
  return map[t] ?? map[u];
}

function localizeMoney(raw: string, locale: string, weights?: DomainWeights): string {
  const v = raw.trim();
  const symNum = new RegExp(`^(${CURRENCY_TOKEN})\\s*([\\d.,]+(?:[.,][\\d]+)?)`, 'i').exec(v);
  if (symNum) {
    const code = currencyCodeFromToken(symNum[1]);
    const num = parseDecimalNumericString(symNum[2]);
    if (code && !Number.isNaN(num)) {
      try {
        const curOpts: Intl.NumberFormatOptions = { style: 'currency', currency: code };
        if (weights && weights.economics >= 0.5) {
          curOpts.minimumFractionDigits = 0;
          curOpts.maximumFractionDigits = 2;
        }
        return new Intl.NumberFormat(locale, curOpts).format(num);
      } catch {
        /* fallthrough */
      }
    }
  }
  const numSym = new RegExp(`^([\\d.,]+(?:[.,][\\d]+)?)\\s*(${CURRENCY_TOKEN})\\s*$`, 'i').exec(v);
  if (numSym) {
    const num = parseDecimalNumericString(numSym[1]);
    const code = currencyCodeFromToken(numSym[2]);
    if (code && !Number.isNaN(num)) {
      try {
        const curOpts: Intl.NumberFormatOptions = { style: 'currency', currency: code };
        if (weights && weights.economics >= 0.5) {
          curOpts.minimumFractionDigits = 0;
          curOpts.maximumFractionDigits = 2;
        }
        return new Intl.NumberFormat(locale, curOpts).format(num);
      } catch {
        /* fallthrough */
      }
    }
  }
  const mag = new RegExp(`^([\\d.,]+(?:[.,][\\d]+)?)\\s*${MAG_WORD}`, 'i').exec(v);
  if (mag) {
    const num = parseDecimalNumericString(mag[1]);
    if (!Number.isNaN(num)) {
      try {
        return new Intl.NumberFormat(locale, { notation: 'compact', compactDisplay: 'short' }).format(num);
      } catch {
        return v;
      }
    }
  }
  return v;
}

function localizePercent(raw: string, locale: string, weights?: DomainWeights): string {
  const m = /^([\d.,]+(?:[.,][\d]+)?)\s*%$/.exec(raw.trim());
  if (!m) return raw;
  const num = parseDecimalNumericString(m[1]);
  if (Number.isNaN(num)) return raw;
  try {
    const maxFrac = weights && weights.politics >= 0.5 ? 4 : 6;
    return new Intl.NumberFormat(locale, { style: 'percent', maximumFractionDigits: maxFrac }).format(
      num / 100
    );
  } catch {
    return raw;
  }
}

function localizePlainNumber(raw: string, locale: string): string {
  const v = raw.trim();
  const m = /^[\d.,]+(?:\.[\d]+)?$/.exec(v);
  if (!m) return raw;
  const num = parseFloat(v.replace(/,/g, ''));
  if (Number.isNaN(num)) return raw;
  try {
    return new Intl.NumberFormat(locale).format(num);
  } catch {
    return raw;
  }
}

/**
 * When Masker type is missing (e.g. legacy vault) or `unknown`, infer date/money/percent
 * so Double OPR still localizes bricks instead of echoing English.
 */
export function inferEntityTypeFromValue(raw: string): 'date' | 'daterange' | 'percent' | 'money' | 'unit' | 'unknown' {
  const v = raw.trim();
  if (!v) return 'unknown';
  if (parseDateLike(v)) return 'date';
  if (/^\d{4}\s*-\s*\d{4}$/.test(v)) return 'daterange';
  if (/^[\d.,]+\s*%$/.test(v)) return 'percent';
  if (resolveUnitIdFromCapture(v) !== null) return 'unit';
  if (
    new RegExp(`^${CURRENCY_TOKEN}\\s*[\\d.,]+`, 'i').test(v) ||
    new RegExp(`^[\\d.,]+(?:\\.[\\d]+)?\\s*${CURRENCY_TOKEN}`, 'i').test(v)
  ) {
    return 'money';
  }
  if (new RegExp(`^[\\d.,]+(?:\\.[\\d]+)?\\s*${MAG_WORD}`, 'i').test(v)) return 'money';
  return 'unknown';
}

function resolveEffectiveType(
  declared: string | undefined,
  value: string
): 'date' | 'daterange' | 'percent' | 'money' | 'unit' | 'unknown' {
  if (
    declared === 'date' ||
    declared === 'daterange' ||
    declared === 'percent' ||
    declared === 'money' ||
    declared === 'unit'
  ) {
    return declared;
  }
  return inferEntityTypeFromValue(value);
}

/**
 * Best-effort micro-transcreation by entity type and target language code (e.g. `ru`, `de`).
 */
export function microTranscreate(
  value: string,
  type: string,
  targetLanguage: string,
  weights?: DomainWeights
): string {
  const locale = resolveLocaleTag(targetLanguage);
  const v = value.trim();
  if (!v) return v;

  const effectiveType = resolveEffectiveType(type, v);

  switch (effectiveType) {
    case 'date': {
      const d = parseDateLike(v);
      return d
        ? sanitizeForTagDisplay(formatDate(d, locale, weights))
        : sanitizeForTagDisplay(v);
    }
    case 'daterange':
      return sanitizeForTagDisplay(localizeDateRange(v, locale));
    case 'percent':
      return sanitizeForTagDisplay(localizePercent(v, locale, weights));
    case 'money':
      return sanitizeForTagDisplay(localizeMoney(v, locale, weights));
    case 'unit':
      return sanitizeForTagDisplay(localizeUnit(v, targetLanguage, weights));
    default:
      return sanitizeForTagDisplay(localizePlainNumber(v, locale));
  }
}
