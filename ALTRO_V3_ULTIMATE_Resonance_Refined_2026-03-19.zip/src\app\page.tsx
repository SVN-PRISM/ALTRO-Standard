/* (c) 2026 SERGEI NAZARIAN | MIT License | ALTRO Core */
'use client';

import { useState } from 'react';
import { ToolsModal } from '@/components/ToolsModal';
import { useAltroPage } from '@/hooks/useAltroPage';
import { ControlPanel } from '@/components/altro/ControlPanel';
import { Workspace } from '@/components/altro/Workspace';
import { HomonymClarifyButton } from '@/components/altro/MeaningMenu';
import { ResonanceWidget } from '@/components/ResonanceWidget';
import { Sidebar } from '@/components/altro/Sidebar';
import { ArchiveModal } from '@/components/altro/ArchiveModal';
import { ArchivePanel } from '@/components/altro/ArchivePanel';
import { ExportModal } from '@/components/altro/ExportModal';
import { ChronosModal } from '@/components/altro/ChronosModal';
import { INITIAL_DOMAIN_WEIGHTS } from '@/lib/altroData';

export default function Test() {
  const [isArchiveOpen, setIsArchiveOpen] = useState(false);
  const [isChronosOpen, setIsChronosOpen] = useState(false);
  const state = useAltroPage();
  const {
    isDark,
    setTheme,
    activePreset,
    applyPreset,
    selectedScenario,
    setSelectedScenario,
    domainWeights,
    setDomainWeights,
    oprPrismValue,
    setOprPrismValue,
    handleInternalDomainChange,
    handleExternalDomainChange,
    toolsModalMode,
    setToolsModalMode,
    sourceText,
    setSourceText,
    setDisplayedAdaptation,
    setAdaptationText,
    sourceTextRef,
    nexusCommand,
    setNexusCommand,
    nexusCommandRef,
    displayedAdaptation,
    adaptationText,
    adaptationDisplayHtml,
    adaptationFlash,
    semanticResetFlash,
    sourceHighlightHtml,
    processedDisplayTokens,
    displayTokens,
    auditLog,
    selectedScannedTokenId,
    resolvedVariants,
    textTokens,
    selectedTokenId,
    setSelectedTokenId,
    showHomonymClarify,
    setShowHomonymClarify,
    unresolvedHomonyms,
    semanticSuggestions,
    selectedSuspiciousTokenId,
    setSelectedSuspiciousTokenId,
    showSuspiciousSuggestion,
    setShowSuspiciousSuggestion,
    homonymClarifyRef,
    suspiciousSuggestionRef,
    handleSourceChange,
    handleNexusResize,
    handleEnterKey,
    handleSourceHomographClick,
    handleSuspiciousSuggestionSelect,
    handleSave,
    handleMirrorTokenClick,
    handleScannedTokenClick,
    handleVariantSelect,
    handleHomonymVariantSelect,
    handleClarifyHomonym,
    clearSource,
    clearSourceInput,
    clearNexus,
    clearAdaptation,
    startEditing,
    processCommand,
    runScan,
    createSnapshot,
    deleteSnapshot,
    applySnapshot,
    formatTimestamp,
    snapshots,
    outputLanguage,
    setOutputLanguage,
    sourceLanguage,
    setSourceLanguage,
    ALTRO_GOLDEN_STATE,
    activePattern,
    hasAdaptationChangesReady,
    isScanning,
    isEditing,
    isSyncing,
    syncDatabase,
    isListening,
    toggleVoiceListening,
    activeFile,
    handleFileUpload,
    nexusFlash,
    securityBlocked,
  } = state;

  const handleScan = () => {
    const nTrim = (nexusCommand || '').trim();
    const sTrim = (sourceText || '').trim();
    if (nTrim.startsWith('/') && processCommand(nTrim)) {
      setNexusCommand('');
      return;
    }
    if (sTrim.startsWith('/') && processCommand(sTrim)) {
      clearSourceInput();
      return;
    }
    runScan(true);
  };

  return (
    <div className={`min-h-screen font-sans p-4 transition-colors flex flex-col overflow-hidden max-h-screen ${isDark ? 'bg-black text-white' : 'bg-gray-100 text-gray-900'}`} style={{ height: '100vh', maxHeight: '100vh' }}>
      <div className="flex flex-1 min-h-0 gap-0 w-full flex-row min-w-0">
        <div className="flex flex-col flex-1 min-w-0 min-h-0 overflow-hidden">
      <header className="flex-shrink-0 border-b pb-2 mb-2 flex items-center justify-between" style={{ borderColor: isDark ? '#1a1a1a' : '#ddd' }}>
        <h1 className="text-base font-bold tracking-widest" style={{ color: '#3b82f6' }}>ALTRO ORCHESTRATOR SVN STANDARD 2026</h1>
        <button type="button" onClick={() => setTheme(!isDark)} className="w-9 h-9 rounded-lg flex items-center justify-center border transition-colors" style={{ borderColor: isDark ? '#333' : '#ddd', background: isDark ? '#111' : '#fff' }} title={isDark ? 'Светлая тема' : 'Тёмная тема'} aria-label={isDark ? 'Light' : 'Dark'}>
          {isDark ? <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" /></svg> : <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" /></svg>}
        </button>
      </header>

      <Workspace
        isDark={isDark}
        isScanning={isScanning}
        isEditing={isEditing}
        sourceText={sourceText}
        nexusCommand={nexusCommand}
        displayedAdaptation={displayedAdaptation}
        adaptationText={adaptationText}
        hasAdaptationChangesReady={hasAdaptationChangesReady}
        sourceHighlightHtml={sourceHighlightHtml}
        adaptationFlash={adaptationFlash}
        displayTokens={(processedDisplayTokens ?? displayTokens) ?? []}
        auditLog={auditLog ?? []}
        selectedScannedTokenId={selectedScannedTokenId}
        resolvedVariants={resolvedVariants}
        activePreset={activePreset}
        adaptationDisplayHtml={adaptationDisplayHtml}
        textTokens={textTokens ?? []}
        selectedTokenId={selectedTokenId}
        showHomonymClarify={showHomonymClarify}
        semanticSuggestions={semanticSuggestions ?? []}
        selectedSuspiciousTokenId={selectedSuspiciousTokenId}
        showSuspiciousSuggestion={showSuspiciousSuggestion}
        nexusCommandRef={nexusCommandRef}
        suspiciousSuggestionRef={suspiciousSuggestionRef}
        onSourceChange={handleSourceChange}
        onNexusChange={setNexusCommand}
        onNexusResize={handleNexusResize}
        onEnterKey={handleEnterKey}
        onClearSourceInput={clearSourceInput}
        onClearSource={clearSource}
        onClearNexus={clearNexus}
        onSave={handleSave}
        onScan={handleScan}
        onSourceHomographClick={handleSourceHomographClick}
        onSuspiciousSuggestionSelect={handleSuspiciousSuggestionSelect}
        onStartEditing={startEditing}
        setNexusCommand={setNexusCommand}
        setSelectedTokenId={setSelectedTokenId}
        setShowHomonymClarify={setShowHomonymClarify}
        setSelectedSuspiciousTokenId={setSelectedSuspiciousTokenId}
        setShowSuspiciousSuggestion={setShowSuspiciousSuggestion}
        normalizeForAuditMatch={state.normalizeForAuditMatch}
        handleMirrorTokenClick={handleMirrorTokenClick}
        handleScannedTokenClick={handleScannedTokenClick}
        handleVariantSelect={handleVariantSelect}
        handleHomonymVariantSelect={handleHomonymVariantSelect}
        handleClarifyHomonym={handleClarifyHomonym}
        clearAdaptation={clearAdaptation}
        sourceLanguage={sourceLanguage}
        setSourceLanguage={setSourceLanguage}
        outputLanguage={outputLanguage}
        setOutputLanguage={setOutputLanguage}
        isListening={isListening}
        onToggleVoice={toggleVoiceListening}
        onFileUpload={handleFileUpload}
        nexusFlash={nexusFlash}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2 flex-shrink-0">
        <div className="flex items-center gap-4 py-2.5 px-3 rounded-lg flex-shrink-0 flex-wrap" style={{ background: isDark ? '#0d0d0d' : '#e8e8e8', border: `1px solid ${isDark ? '#1a1a1a' : '#ccc'}` }}>
          {(['mirror', 'transfigure'] as const).map((p) => (
            <button
              key={p}
              type="button"
              onClick={() => applyPreset(p)}
              title={p === 'mirror' ? 'Подстрочник 1-в-1' : 'Транскреация'}
              className="text-[9px] px-2 py-1 rounded border font-semibold uppercase tracking-wider transition-colors whitespace-nowrap"
              style={{
                borderColor: activePreset === p ? '#3b82f6' : isDark ? '#333' : '#aaa',
                background: activePreset === p ? 'rgba(59,130,246,0.2)' : isDark ? '#111' : '#fff',
                color: activePreset === p ? '#60a5fa' : isDark ? '#e5e7eb' : '#111',
              }}
            >
              {p === 'mirror' ? 'ЗЕРКАЛО' : 'ТРАНСКРЕАЦИЯ'}
            </button>
          ))}
          <button
            type="button"
            onClick={syncDatabase}
            disabled={isSyncing}
            className="text-[9px] px-2 py-1 rounded border font-semibold uppercase tracking-wider transition-colors whitespace-nowrap"
            style={{
              borderColor: isSyncing ? '#22c55e' : isDark ? '#333' : '#aaa',
              background: isSyncing ? 'rgba(34,197,94,0.15)' : isDark ? '#111' : '#fff',
              color: isSyncing ? '#22c55e' : isDark ? '#e5e7eb' : '#111',
            }}
          >
            DATA SYNC
          </button>
          <HomonymClarifyButton isDark={isDark} textTokens={textTokens ?? []} selectedTokenId={selectedTokenId} showHomonymClarify={showHomonymClarify} unresolvedHomonyms={unresolvedHomonyms ?? []} handleHomonymVariantSelect={handleHomonymVariantSelect} handleClarifyHomonym={handleClarifyHomonym} setShowHomonymClarify={setShowHomonymClarify} setSelectedTokenId={setSelectedTokenId} homonymClarifyRef={homonymClarifyRef} />
          <button
            type="button"
            onClick={state.clearAll}
            className="text-[9px] px-2 py-1 rounded border font-semibold uppercase tracking-wider whitespace-nowrap transition-all duration-300"
            style={{
              borderColor: semanticResetFlash ? '#22c55e' : isDark ? '#333' : '#aaa',
              background: semanticResetFlash ? 'rgba(34,197,94,0.15)' : isDark ? '#111' : '#fff',
              color: semanticResetFlash ? '#22c55e' : isDark ? '#e5e7eb' : '#111',
              boxShadow: semanticResetFlash ? '0 0 12px rgba(34,197,94,0.4)' : 'none',
            }}
            title={semanticResetFlash ? 'Исходное безопасное состояние' : 'Полный семантический сброс'}
          >
            ОЧИСТИТЬ
          </button>
        </div>
        <div className="flex items-center py-2 px-3 rounded-lg flex-shrink-0" style={{ background: isDark ? '#0d0d0d' : '#e8e8e8', border: `1px solid ${isDark ? '#1a1a1a' : '#ccc'}` }}>
          <div className="flex items-center gap-3 font-mono text-[9px] w-full">
            <span className="uppercase tracking-wider" style={{ color: '#6b7280' }}>Режим:</span>
            <span className="font-semibold" style={{ color: activePreset !== 'mirror' ? (isDark ? '#60a5fa' : '#3b82f6') : (isDark ? '#6b7280' : '#9ca3af') }}>{activePreset === 'mirror' ? 'Зеркало' : activePreset === 'transfigure' ? 'Транскреация' : 'Зеркало'}</span>
            <span style={{ color: '#6b7280' }}>|</span>
            <span className="uppercase tracking-wider" style={{ color: '#6b7280' }}>Паттерн:</span>
            <span className="font-semibold" style={{ color: (activePattern || selectedScenario !== 'without') ? (isDark ? '#60a5fa' : '#3b82f6') : (isDark ? '#6b7280' : '#9ca3af') }}>{activePreset === 'mirror' ? '—' : activePattern ? activePattern.name : selectedScenario !== 'without' ? (selectedScenario === 'goldStandard' ? 'Gold Standard' : selectedScenario) : '—'}</span>
            <span style={{ color: '#6b7280' }}>|</span>
            <span className="uppercase tracking-wider" style={{ color: '#6b7280' }}>Контекст:</span>
            <span className="font-semibold" style={{ color: ALTRO_GOLDEN_STATE?.trim() ? '#22c55e' : (isDark ? '#6b7280' : '#9ca3af') }}>{ALTRO_GOLDEN_STATE?.trim() ? '✓' : '—'}</span>
          </div>
        </div>
      </div>

      <ControlPanel isDark={isDark} domainWeights={domainWeights} oprPrismValue={oprPrismValue} setOprPrismValue={setOprPrismValue} activePreset={activePreset} handleInternalDomainChange={handleInternalDomainChange} handleExternalDomainChange={handleExternalDomainChange} isScanning={isScanning} />

      <ToolsModal isOpen={toolsModalMode !== null} onClose={() => setToolsModalMode(null)} title={toolsModalMode === 'snapshot' ? 'Слепок настроек' : toolsModalMode === 'archive' ? 'Архив текстов (Результаты транскреаций)' : 'Экспорт данных ALTRO'} isDark={isDark}>
        {toolsModalMode === 'snapshot' && (
          <div className="flex flex-col gap-3">
            <button type="button" onClick={() => { createSnapshot(); setToolsModalMode(null); }} className="text-[10px] px-3 py-2 rounded border font-semibold uppercase tracking-wider w-full transition-colors" style={{ borderColor: '#C8A2C8', background: 'rgba(200,162,200,0.15)', color: isDark ? '#e5e7eb' : '#111' }}>Создать новый слепок</button>
            <div className="text-[9px] uppercase tracking-wider" style={{ color: '#6b7280' }}>Существующие:</div>
            {snapshots.length === 0 ? <span className="text-[10px]" style={{ color: '#6b7280' }}>Нет слепков</span> : (
              <ul className="flex flex-col gap-1.5 max-h-40 overflow-y-auto">
                {snapshots.map((s) => (
                  <li key={s.id} className="flex items-center justify-between gap-2 py-1.5 px-2 rounded border" style={{ borderColor: isDark ? '#333' : '#e5e7eb' }}>
                    <span className="text-[10px] truncate flex-1" style={{ color: isDark ? '#e5e7eb' : '#374151' }}>{formatTimestamp(s.timestamp)}</span>
                    <div className="flex items-center gap-1 flex-shrink-0">
                      <button type="button" onClick={() => { applySnapshot(s); setToolsModalMode(null); }} className="text-[9px] px-1.5 py-0.5 rounded border" style={{ borderColor: '#C8A2C8', color: '#C8A2C8' }}>Применить</button>
                      <button type="button" onClick={() => deleteSnapshot(s.id)} className="text-[9px] px-1.5 py-0.5 rounded border opacity-60 hover:opacity-100" style={{ borderColor: isDark ? '#555' : '#999', color: isDark ? '#9ca3af' : '#6b7280' }}>×</button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}
        {toolsModalMode === 'archive' && (
          <ArchivePanel
            isDark={isDark}
            onCopyToSource={(source) => {
              setSourceText(source);
              sourceTextRef.current = source;
            }}
            onApplyResult={(source, result) => {
              setSourceText(source);
              sourceTextRef.current = source;
              setDisplayedAdaptation(result);
              setAdaptationText(result);
            }}
            onClose={() => setToolsModalMode(null)}
          />
        )}
        {toolsModalMode === 'export' && (
          <ExportModal
            isDark={isDark}
            currentResult={(displayedAdaptation || sourceText || '').trim()}
            onClose={() => setToolsModalMode(null)}
          />
        )}
      </ToolsModal>

      <ResonanceWidget 
        isDark={isDark} 
        domainWeights={domainWeights} 
        oprSlider={oprPrismValue} 
        isListening={isListening} 
        activeFileName={activeFile?.name}
        isFileProcessing={activeFile?.isProcessing}
        securityBlocked={securityBlocked}
      />

      <ArchiveModal
        isOpen={isArchiveOpen}
        onClose={() => setIsArchiveOpen(false)}
        isDark={isDark}
        onSelectRecord={(record) => {
          setSourceText(record.source);
          sourceTextRef.current = record.source;
          setDisplayedAdaptation(record.result);
          setAdaptationText(record.result);
          const radar = record.radar ?? {};
          const migratedRadar = { ...radar, spirituality: radar.spirituality ?? (radar as Record<string, number>).religion ?? 0 };
          if ('religion' in migratedRadar) delete (migratedRadar as Record<string, number>).religion;
          setDomainWeights({ ...INITIAL_DOMAIN_WEIGHTS, ...migratedRadar });
          setOprPrismValue(Math.max(0, Math.min(100, record.resonance ?? 0)));
          setNexusCommand(record.nexusCommand ?? '');
          setIsArchiveOpen(false);
        }}
      />

      <ChronosModal
        isOpen={isChronosOpen}
        onClose={() => setIsChronosOpen(false)}
        isDark={isDark}
      />

      <footer className="mt-2 pt-2 pb-1 flex-shrink-0 text-[9px]" style={{ borderTop: '1px solid ' + (isDark ? '#0a0a0a' : '#ddd'), color: isDark ? '#4b5563' : '#6b7280' }}>
        (c) 2026 SERGEI NAZARIAN (SVN) | ALTRO Semantic Orchestration Layer
      </footer>
        </div>
        <Sidebar
          isDark={isDark}
          selectedScenario={selectedScenario}
          setSelectedScenario={setSelectedScenario}
          setDomainWeights={setDomainWeights}
          activePreset={activePreset}
          setToolsModalMode={setToolsModalMode}
          onSaveSnapshot={handleSave}
          onOpenArchive={() => setIsArchiveOpen(true)}
          onOpenChronos={() => setIsChronosOpen(true)}
          securityBlocked={securityBlocked}
        />
      </div>
    </div>
  );
}
