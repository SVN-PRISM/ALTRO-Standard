/* ALTRO Core | MIT License | SERGEI NAZARIAN (SVN) */

import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'ALTRO Core - Transcreation System',
  description: 'ALTRO Core System for transcreation validation',
  icons: { icon: '/favicon.ico' },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ru" className="h-full overflow-hidden">
      <body className="h-full max-h-screen overflow-hidden">{children}</body>
    </html>
  );
}
