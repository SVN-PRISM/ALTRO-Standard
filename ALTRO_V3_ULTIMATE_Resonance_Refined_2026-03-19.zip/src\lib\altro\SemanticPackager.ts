/* MIT License | Copyright (c) 2026 SERGEI NAZARIAN (SVN) | ALTRO: IPA Phase 1 — Semantic Packager */

/**
 * SemanticPackager — разделение запроса на Аналитическую и Исполнительную фазы.
 * IPA (Intent-Packet-Adaptation): сборка семантического пакета для контекста транскреации.
 */

import type { DomainWeights } from '@/lib/altroData';
import { EXTERNAL_DOMAIN_KEYS, INTERNAL_DOMAIN_KEYS } from '@/lib/altroData';
import { AltroTokenManager } from './tokenManager';

const DOMAIN_LABELS: Record<string, string> = {
  economics: 'Экономика',
  politics: 'Политика',
  society: 'Общество',
  history: 'История',
  culture: 'Культура',
  aesthetics: 'Эстетика',
  technology: 'Технологии',
  spirituality: 'Духовность',
  semantics: 'Семантика',
  context: 'Контекст',
  intent: 'Намерение',
  imagery: 'Образность',
  ethics: 'Этика',
};

export interface SemanticPacket {
  intent_summary: string;
  domain_focus: [string, string, string];
  structural_anchors: string[];
}

/** Вычисляет 3 доминирующих домена по абсолютным весам. */
function getTop3Domains(weights: DomainWeights): [string, string, string] {
  const allKeys = [...EXTERNAL_DOMAIN_KEYS, ...INTERNAL_DOMAIN_KEYS];
  const scored = allKeys.map((k) => ({
    key: k,
    abs: Math.abs((weights as Record<string, number>)[k] ?? 0),
  }));
  scored.sort((a, b) => b.abs - a.abs);
  const top3 = scored.slice(0, 3).map((s) => s.key);
  return [
    top3[0] ?? 'semantics',
    top3[1] ?? 'context',
    top3[2] ?? 'intent',
  ];
}

/** Извлекает ключевые слова/знаки для сохранения (слова с U+0301, locked, длинные термины). */
function extractStructuralAnchors(sourceText: string, lockedWords?: string[]): string[] {
  const anchors: string[] = [];
  if (lockedWords?.length) anchors.push(...lockedWords);

  const tokens = AltroTokenManager.tokenize(sourceText);
  for (const t of tokens) {
    if (t.type !== 'word') continue;
    const w = t.word;
    if (/\u0301/.test(w)) anchors.push(w);
    if (t.isLocked && w.length > 2) anchors.push(w);
    if (w.length >= 12 && /[А-Яа-яЁёA-Za-z]/.test(w)) anchors.push(w);
  }
  return [...new Set(anchors)].slice(0, 10);
}

/**
 * Формирует краткий JSON-пакет из sourceText и weights (локальный fallback).
 * Используется при откате IPA или для предзаполнения перед LLM-анализом.
 */
export function generatePacket(
  sourceText: string,
  weights: DomainWeights,
  lockedWords?: string[]
): SemanticPacket {
  const domain_focus = getTop3Domains(weights);
  const structural_anchors = extractStructuralAnchors(sourceText, lockedWords);
  const domainLabels = domain_focus.map((k) => DOMAIN_LABELS[k] ?? k).join(', ');
  const intent_summary = `Транскреация с фокусом на домены: ${domainLabels}. Сохранить структурные якоря.`;
  return { intent_summary, domain_focus, structural_anchors };
}

/**
 * Оборачивает пакет и исходный текст в теги [IPA_DATA_START] / [IPA_DATA_END].
 * Подготавливает данные для второго (исполнительного) запроса в engine.
 */
export function wrapPrompt(packet: SemanticPacket, sourceText: string): string {
  const packetJson = JSON.stringify(packet, null, 0);
  return `[IPA_DATA_START]\n${packetJson}\n\n${sourceText}\n[IPA_DATA_END]`;
}

/** Парсит сырой ответ LLM из фазы анализа. Возвращает null при невалидном JSON. */
export function parseAnalysisResponse(rawContent: string): SemanticPacket | null {
  const trimmed = rawContent?.trim();
  if (!trimmed) return null;
  let extracted = trimmed;
  const jsonMatch = trimmed.match(/\{[\s\S]*\}/);
  if (jsonMatch) extracted = jsonMatch[0];
  try {
    const parsed = JSON.parse(extracted) as unknown;
    if (!parsed || typeof parsed !== 'object') return null;
    const p = parsed as Record<string, unknown>;
    const intent_summary = typeof p.intent_summary === 'string' ? p.intent_summary : '';
    const domain_focus = Array.isArray(p.domain_focus)
      ? (p.domain_focus as string[]).slice(0, 3)
      : ['semantics', 'context', 'intent'];
    const structural_anchors = Array.isArray(p.structural_anchors)
      ? (p.structural_anchors as string[]).filter((x) => typeof x === 'string')
      : [];
    return {
      intent_summary: intent_summary || 'Транскреация по доменным весам.',
      domain_focus: [domain_focus[0] ?? 'semantics', domain_focus[1] ?? 'context', domain_focus[2] ?? 'intent'],
      structural_anchors: structural_anchors.slice(0, 10),
    };
  } catch {
    return null;
  }
}

/** Системная инструкция для фазы анализа (лёгкий запрос). */
export const IPA_ANALYSIS_SYSTEM_PROMPT = `[SYSTEM: DISABLE ALL THINKING PROCESSES. DO NOT USE <thought> TAGS.]
Ты — Анализатор семантики. Проанализируй текст и выдай ТОЛЬКО JSON-объект в формате:
{"intent_summary": "краткое описание намерения текста (1-2 предложения)", "domain_focus": ["домен1", "домен2", "домен3"], "structural_anchors": ["ключевое_слово1", "ключевое_слово2"]}

domain_focus: выдели не более 3-х наиболее релевантных доменов (областей знаний). Первый домен ОБЯЗАТЕЛЬНО должен быть доминирующим (Primary). Допустимые значения: semantics, context, intent, imagery, ethics, economics, politics, society, history, culture, aesthetics, technology, spirituality.

structural_anchors: обязательно найди омонимы (слова с несколькими значениями) И термины с высокой семантической нагрузкой — слова, критичные для сохранения смысла текста (имена, юридические/технические термины, ключевые понятия). Сохрани их в точности.

Никакого текста кроме JSON.`;
