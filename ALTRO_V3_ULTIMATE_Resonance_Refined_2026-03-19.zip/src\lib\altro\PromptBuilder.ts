/* MIT License | Copyright (c) 2026 SERGEI NAZARIAN (SVN) | ALTRO: Prompt Generation */

/**
 * PromptBuilder — формирование системных промптов для LLM.
 * Вынесено из engine.ts для декомпозиции.
 */

import { HOMONYM_DB, HOMONYM_WORD_FORMS } from '@/lib/altroData';
import { getActiveDomainsList } from './domain-processor';
import { ALTRO_GOLDEN_STANDARD_MANIFEST } from './foundation';
import type { WordDefinitions } from './dictionary';
import type { SemanticPacket } from './SemanticPackager';

export type PresetMode = 'mirror' | 'transfigure' | 'slang' | 'data_query';
export type ScenarioType = 'without' | 'poetics' | 'technocrat' | 'sacred' | 'goldStandard';

export interface AltroCalibration {
  internal: {
    semantics: number;
    context: number;
    intent: number;
    imagery: number;
    ethics: number;
  };
  external: {
    economics: number;
    politics: number;
    society: number;
    history: number;
    culture: number;
    aesthetics: number;
    technology: number;
    spirituality: number;
  };
  opr?: number;
  scenario: ScenarioType;
}

export interface BuildPromptParams {
  mode: PresetMode;
  calibration: AltroCalibration;
  targetLanguage?: string;
  goldenReserveWords?: Array<{ word: string; tokenId: number; definitions: WordDefinitions }>;
  sourceText?: string;
  directive?: string;
  isFinalAdaptation?: boolean;
  domainEngineDirective?: string;
  hasHomonymClarifications?: boolean;
  lockedMeaningLines?: string[];
  /** Семантический пакет из IPA Phase 1. При наличии — внедряется блок инструкций по structural_anchors. */
  semanticPacket?: SemanticPacket | null;
}

const SYSTEM_DISABLE_THINKING_HEADER =
  '[SYSTEM: DISABLE ALL THINKING PROCESSES. DO NOT USE <thought> TAGS. DO NOT SHOW REASONING.]';

export const MIRROR_LIGHT_PROMPT = `${SYSTEM_DISABLE_THINKING_HEADER} Strictly return ONLY a JSON object with the 'text' field. No conversational fillers or meta-talk. Верни JSON объект с полем text, где в словах-омонимах проставлены знаки \u0301. Больше ничего не пиши. Strictly preserve all punctuation, including quotes (« ») and trailing periods (.). Do not sanitize the output. Do not strip any characters. Preserve « » and dots exactly as in source.`;

export const SCAN_AUDIT_PROMPT = `Ты — Сканер. Найди омонимы и многозначные слова. Верни только JSON-массив: [{"word": "косой", "variants": ["инструмент", "прическа", "взгляд"]}]. Не переписывай текст!`;

const REFINEMENT_SYSTEM_PROMPT = `[SYSTEM: DISABLE ALL THINKING. NO <thought> TAGS.]
REFINEMENT: Восстанови в тексте утерянные смыслы. Внедри указанные термины в [RESTORE] в соответствующие места. Сохрани структуру и стиль. Вывод ТОЛЬКО между [OUTPUT_START] и [OUTPUT_END].`;

/** Формирует промпт для повторного вызова LLM при score < 0.8 (восстановление утерянных смыслов). */
export function buildRefinementPrompt(
  originalText: string,
  currentOutput: string,
  lostMeanings: string[]
): { systemPrompt: string; userContent: string } {
  const restoreList = lostMeanings.length > 0 ? lostMeanings.join(', ') : '';
  const userContent = `[ORIGINAL]\n${originalText}\n\n[CURRENT]\n${currentOutput}\n\n[RESTORE] ${restoreList}\n\nВерни исправленный текст между [OUTPUT_START] и [OUTPUT_END].`;
  return { systemPrompt: REFINEMENT_SYSTEM_PROMPT, userContent };
}

/** Builds [LOCKED_MEANING] lines for prompt (Method B). */
export function buildLockedMeaningLines(
  resolvedVariantsHint: string | undefined,
  lockedTokens: Array<{ word: string; meaning?: string }>
): string[] {
  const lines: string[] = [];
  const seen = new Set<string>();
  const add = (word: string, accentedOrMeaning: string, meaning?: string) => {
    const key = word.toLowerCase().replace(/\s/g, '');
    if (seen.has(key)) return;
    seen.add(key);
    const norm = word.trim();
    if (meaning != null && meaning !== accentedOrMeaning) {
      lines.push(`${norm} = ${accentedOrMeaning} (${meaning})`);
    } else {
      lines.push(`${norm} = ${accentedOrMeaning}`);
    }
  };
  if (resolvedVariantsHint?.trim()) {
    const pairs = resolvedVariantsHint.split(/[;\n]/).map((s) => s.trim()).filter(Boolean);
    for (const pair of pairs) {
      const match = pair.match(/\[([^\]]+)\]\s*=\s*(.+)/) || pair.match(/^(\S+)\s*=\s*(.+)$/);
      if (match) {
        const word = match[1].trim();
        const value = match[2].trim();
        const base = word.toLowerCase().replace(/[\u0301]/g, '');
        const entry = HOMONYM_DB.find((e) => e.base.toLowerCase() === base || (HOMONYM_WORD_FORMS[base] ?? base) === e.base.toLowerCase());
        const variant = entry?.variants?.find(
          (v) =>
            v.meaning === value ||
            (v.meaning && (v.meaning.startsWith(value) || v.meaning.includes(value))) ||
            v.word === value ||
            (v.word && v.word.replace(/[\u0301]/g, '') === value.replace(/[\u0301]/g, ''))
        );
        const accentedWord = variant?.word ?? value;
        add(word, accentedWord, value);
      }
    }
  }
  for (const t of lockedTokens) {
    if (t.meaning) add(t.word, t.word, t.meaning);
  }
  return lines;
}

/**
 * Формирует системный промпт для LLM (ALTRO CORE PROTOCOL v2.0 — Execution Manifest).
 */
export function buildSystemPrompt(params: BuildPromptParams): string {
  const { mode, calibration, targetLanguage, isFinalAdaptation = true, hasHomonymClarifications, lockedMeaningLines } = params;

  if (mode === 'mirror') {
    const lang = targetLanguage ?? 'ru';
    const parts: string[] = [
      SYSTEM_DISABLE_THINKING_HEADER,
      'ALTRO CORE PROTOCOL v2.0 — MIRROR EXECUTION.',
      `[LANG] TARGET=${lang.toUpperCase()}`,
    ];
    if (lockedMeaningLines?.length) {
      parts.push('[LOCKED_MEANING]');
      parts.push(...lockedMeaningLines);
    }
    parts.push(
      '[IO_CONTRACT]',
      '- Read source ONLY between [INPUT_START] and [INPUT_END].',
      '- Write output ONLY between [OUTPUT_START] and [OUTPUT_END].',
      'ACTION: Perform 1:1 isomorphic byte-level reflection of the segment between [INPUT_START] and [INPUT_END]. Preserve all characters byte-for-byte, including Unicode U+0301 accents and quotation marks « » „ “ exactly as they appear in the input.',
      'OUTPUT_FORMAT: JSON object with a single field "text" containing the reflected string.'
    );
    return parts.join('\n');
  }

  if (mode === 'data_query') {
    const lang = targetLanguage ?? 'sql_intent';
    const parts: string[] = [
      SYSTEM_DISABLE_THINKING_HEADER,
      'ALTRO DATA PROTOCOL v1.0 — SQL-INTENT MANIFEST.',
      `[MODE] DATA_QUERY`,
      `[LANG] TARGET=${lang.toUpperCase()}`,
    ];
    if (lockedMeaningLines?.length) {
      parts.push('[LOCKED_MEANING]');
      parts.push(...lockedMeaningLines);
    }
    parts.push(
      '[IO_CONTRACT]',
      '- Read natural-language request ONLY between [INPUT_START] and [INPUT_END].',
      '- Do NOT generate raw SQL.',
      'ACTION: Build a pure semantic intent object for querying Firebird (entity, fields, filters, locked filters), not SQL.',
      'OUTPUT_FORMAT: JSON object { "entity": string, "fields": string[], "filters": [...], "lockedFilters": [...] }.'
    );
    return parts.join('\n');
  }

  const lang = targetLanguage ?? 'ru';
  const internal = calibration?.internal ?? {
    semantics: 0,
    context: 0,
    intent: 0,
    imagery: 0,
    ethics: 0,
  };

  const domains = getActiveDomainsList(calibration) ?? [];
  const domainsStr = domains.length > 0 ? domains.join(', ') : '—';

  const scriptPurity =
    lang === 'hy'
      ? 'Script Purity: Armenian only (U+0530–U+058F). No mixing.'
      : `Script Purity: ${lang.toUpperCase()} alphabet only. No mixing.`;

  const homonymRule = hasHomonymClarifications ? 'Preserve locked accents/meanings exactly as provided.' : 'If no locked meanings are provided, do not invent new homonym interpretations.';
  const directive = params.directive?.trim();
  const directiveLine = directive ? `[DIRECTIVE] ${directive}\n` : '';
  const domainEngineLine = params.domainEngineDirective?.trim() ? `[DOMAIN_ENGINE] ${params.domainEngineDirective}\n` : '';

  const domainSilenceLine = !isFinalAdaptation
    ? '[DOMAIN_SILENCE] This is a calibration phase. Do NOT apply creative domain transformations. Preserve semantics; only apply technical corrections if absolutely necessary.'
    : '';

  const lockBlock =
    lockedMeaningLines?.length
      ? ['[LOCKED_MEANING]', ...lockedMeaningLines].join('\n')
      : '';

  const semanticAnchorsBlock =
    params.semanticPacket != null &&
    typeof params.semanticPacket === 'object' &&
    ((params.semanticPacket.structural_anchors?.length ?? 0) > 0 ||
      !!params.semanticPacket.intent_summary?.trim() ||
      (params.semanticPacket.domain_focus?.length ?? 0) > 0)
      ? [
          '[IPA_CONTEXT] Используй семантический пакет в [IPA_DATA_START] как контекст для адаптации. Исходный текст — между пакетом и [IPA_DATA_END].',
          '### СТРОГОЕ СОБЛЮДЕНИЕ СЕМАНТИЧЕСКИХ ЯКОРЕЙ:',
          'Если в [IPA_DATA_START] указаны structural_anchors, ты ОБЯЗАН:',
          '1. Использовать указанный контекст для каждого омонима или спорного термина.',
          '2. Не выходить за рамки определенного интента (intent).',
          '3. Сохранять тональность, заданную в пакете анализа.',
          'Запрещено самовольно менять интерпретацию терминов, зафиксированных на Фазе 1.',
        ].join('\n')
      : '';

  const manifestLines = [
    SYSTEM_DISABLE_THINKING_HEADER,
    ALTRO_GOLDEN_STANDARD_MANIFEST,
    'ALTRO CORE PROTOCOL v2.0 — EXECUTION MANIFEST.',
    ...(lockBlock ? [lockBlock] : []),
    ...(semanticAnchorsBlock ? [semanticAnchorsBlock] : []),
    `[MODE] ${mode.toUpperCase()}`,
    `[LANG] TARGET=${lang.toUpperCase()}`,
    `[WEIGHTS] Semantics=${internal.semantics}; Context=${internal.context}; Intent=${internal.intent}; Imagery=${internal.imagery}; Ethics=${internal.ethics}.`,
    `[DOMAINS_ACTIVE] ${domainsStr}`,
    `[OPR_FILTER] Level=2. Enforce Object–Predicate relations. Reject outputs that drop subjects, predicates or turn full sentences into fragments. Preserve minimal length and argumentative structure so that each object keeps its predicate.`,
    `[SCRIPT_PURITY] ${scriptPurity}`,
    `[STRESS_PROTECTION] Preserve U+0301 accent marks exactly. Do NOT remove, move or normalize them. Preserve all quotation marks « », „ “ and all punctuation and special symbols from the input. Do not strip, sanitize or normalize characters.`,
    `[HOMONYM_LOCKS] ${homonymRule}`,
    '[IO_CONTRACT]',
    '- The source text will be provided between [INPUT_START] and [INPUT_END].',
    '- You MUST read ONLY that span as input.',
    `Mode=${mode.toUpperCase()}.
[OUTPUT_CONTRACT]
- Wrap the entire adaptation strictly between [OUTPUT_START] and [OUTPUT_END].
- Do not add any characters before [OUTPUT_START] or after [OUTPUT_END].
- Do not add comments, meta-talk or conversational fillers. Output the adaptation only.`,
    domainSilenceLine,
    directiveLine.trimEnd(),
    domainEngineLine.trimEnd(),
  ].filter((line) => line !== '').join('\n');
  return manifestLines;
}
