/* MIT License | Copyright (c) 2026 SERGEI NAZARIAN (SVN) | ALTRO: Semantic Orchestration Layer */

/**
 * API Route: /api/transcreate
 * Проксирует запросы к Ollama /api/chat.
 * stream: true — прокидывает стрим; stream: false — ждёт полный ответ.
 * AltroSafetyGuard (Vector №3) проверяет ETHICS/LAW перед отправкой в LLM.
 */

import { checkRequest } from '@/security/AltroSafetyGuard';

const OLLAMA_BASE = process.env.OLLAMA_BASE_URL ?? 'http://localhost:11434';
const OLLAMA_TIMEOUT_MS = 120_000;
// TODO: Model Switching Logic based on Semantic Pack (Qwen 3.5 9b / Qwen 2.5 14b)

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const guardResult = checkRequest(body);
    if (!guardResult.allowed) {
      console.warn('[ALTRO SAFETY] Request blocked:', guardResult.code, guardResult.reason);
      return Response.json(
        { error: 'Security Policy Violation', code: guardResult.code, reason: guardResult.reason },
        { status: 403 }
      );
    }
    const debug = body?._altroDebug;
    if (debug) {
      console.log(`Target Language set to: ${(debug.targetLanguage ?? 'ru').toUpperCase()} | OPR Intensity: ${debug.oprIntensity ?? 0}`);
      if (debug.sourceLanguageDetected) {
        console.log(`Source Language Detected: ${String(debug.sourceLanguageDetected).toUpperCase()}`);
      }
      delete body._altroDebug;
    }
    const systemPrompt = body?.messages?.[0]?.content;
    if (systemPrompt != null) {
      console.log('FINAL_SYSTEM_PROMPT:', systemPrompt);
    }
    const response = await fetch(`${OLLAMA_BASE}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(OLLAMA_TIMEOUT_MS),
    });

    if (!response.ok) {
      return Response.json(
        { error: '[ALTRO ERROR: Сбой связи с Ядром. Перезапустите Ollama]' },
        { status: 502 }
      );
    }

    if (body.stream === true && response.body) {
      return new Response(response.body, {
        headers: { 'Content-Type': 'application/json' },
      });
    }

    const data = await response.json();
    return Response.json(data);
  } catch (err) {
    console.error('ALTRO transcreate proxy error:', err);
    return Response.json(
      { error: '[ALTRO ERROR: Сбой связи с Ядром. Перезапустите Ollama]' },
      { status: 502 }
    );
  }
}
